'use client'

import Link from 'next/link'
import { useState, useRef } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { 
  Building2, 
  FileText, 
  Upload, 
  Download, 
  Search,
  Home,
  Bell,
  Settings,
  Calendar,
  Filter,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Tag,
  Folder,
  Star,
  AlertTriangle
} from "lucide-react"

export default function Documents() {
  const [activeTab, setActiveTab] = useState("all")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedProperty, setSelectedProperty] = useState("all")
  const [isUploading, setIsUploading] = useState(false)
  const [documents, setDocuments] = useState([])
  const [showUploadDialog, setShowUploadDialog] = useState(false)
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [uploadForm, setUploadForm] = useState({
    propertyId: '',
    documentType: 'OTHER',
    description: '',
    expiresAt: '',
    tenancyId: ''
  })
  const fileInputRef = useRef<HTMLInputElement>(null)

  // Mock document data - this will be replaced with API calls
  const mockDocuments = [
    {
      id: 1,
      name: "Gas Safety Certificate",
      type: "certificate",
      category: "safety",
      property: "123 Main Street, London",
      uploadDate: "2024-01-10",
      expiryDate: "2025-01-10",
      size: "2.4 MB",
      format: "PDF",
      status: "valid",
      tags: ["gas", "safety", "certificate"],
      starred: true
    },
    {
      id: 2,
      name: "EPC Certificate",
      type: "certificate",
      category: "energy",
      property: "456 Park Avenue, Manchester",
      uploadDate: "2023-12-15",
      expiryDate: "2033-12-15",
      size: "1.8 MB",
      format: "PDF",
      status: "valid",
      tags: ["epc", "energy", "certificate"],
      starred: false
    },
    {
      id: 3,
      name: "Tenancy Agreement - John Smith",
      type: "agreement",
      category: "legal",
      property: "123 Main Street, London",
      uploadDate: "2024-01-05",
      expiryDate: "2025-01-05",
      size: "856 KB",
      format: "PDF",
      status: "active",
      tags: ["tenancy", "agreement", "legal"],
      starred: true
    },
    {
      id: 4,
      name: "Electrical Safety Report",
      type: "report",
      category: "safety",
      property: "789 High Street, Birmingham",
      uploadDate: "2023-11-20",
      expiryDate: "2024-11-20",
      size: "3.2 MB",
      format: "PDF",
      status: "valid",
      tags: ["electrical", "safety", "report"],
      starred: false
    },
    {
      id: 5,
      name: "Fire Risk Assessment",
      type: "assessment",
      category: "safety",
      property: "456 Park Avenue, Manchester",
      uploadDate: "2023-10-15",
      expiryDate: "2024-10-15",
      size: "1.5 MB",
      format: "PDF",
      status: "valid",
      tags: ["fire", "safety", "assessment"],
      starred: false
    },
    {
      id: 6,
      name: "HMO License",
      type: "license",
      category: "legal",
      property: "456 Park Avenue, Manchester",
      uploadDate: "2023-09-01",
      expiryDate: "2025-09-01",
      size: "945 KB",
      format: "PDF",
      status: "valid",
      tags: ["hmo", "license", "legal"],
      starred: true
    },
    {
      id: 7,
      name: "Inventory Report",
      type: "report",
      category: "property",
      property: "789 High Street, Birmingham",
      uploadDate: "2024-01-08",
      expiryDate: null,
      size: "2.1 MB",
      format: "PDF",
      status: "current",
      tags: ["inventory", "property", "report"],
      starred: false
    },
    {
      id: 8,
      name: "Deposit Protection Certificate",
      type: "certificate",
      category: "financial",
      property: "123 Main Street, London",
      uploadDate: "2024-01-05",
      expiryDate: "2025-01-05",
      size: "678 KB",
      format: "PDF",
      status: "active",
      tags: ["deposit", "protection", "certificate"],
      starred: false
    }
  ]

  const categories = [
    { value: "all", label: "All Categories" },
    { value: "safety", label: "Safety & Compliance" },
    { value: "legal", label: "Legal Documents" },
    { value: "financial", label: "Financial" },
    { value: "property", label: "Property" },
    { value: "energy", label: "Energy" }
  ]

  const properties = [
    { value: "all", label: "All Properties" },
    { value: "123 Main Street, London", label: "123 Main Street, London" },
    { value: "456 Park Avenue, Manchester", label: "456 Park Avenue, Manchester" },
    { value: "789 High Street, Birmingham", label: "789 High Street, Birmingham" }
  ]

  const documentStats = {
    total: mockDocuments.length,
    starred: mockDocuments.filter(d => d.starred).length,
    expiringSoon: mockDocuments.filter(d => {
      if (!d.expiryDate) return false
      const expiry = new Date(d.expiryDate)
      const now = new Date()
      const diffTime = expiry.getTime() - now.getTime()
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
      return diffDays <= 30 && diffDays > 0
    }).length,
    expired: mockDocuments.filter(d => {
      if (!d.expiryDate) return false
      return new Date(d.expiryDate) < new Date()
    }).length
  }

  const filteredDocuments = mockDocuments.filter(doc => {
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         doc.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    const matchesCategory = selectedCategory === "all" || doc.category === selectedCategory
    const matchesProperty = selectedProperty === "all" || doc.property === selectedProperty
    
    return matchesSearch && matchesCategory && matchesProperty
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "valid": return "default"
      case "active": return "default"
      case "current": return "default"
      case "expired": return "destructive"
      default: return "secondary"
    }
  }

  const getExpiryStatus = (expiryDate: string | null) => {
    if (!expiryDate) return null
    
    const expiry = new Date(expiryDate)
    const now = new Date()
    const diffTime = expiry.getTime() - now.getTime()
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))
    
    if (diffDays < 0) return { status: "expired", days: Math.abs(diffDays) }
    if (diffDays <= 30) return { status: "expiring-soon", days: diffDays }
    if (diffDays <= 90) return { status: "expiring", days: diffDays }
    return { status: "valid", days: diffDays }
  }

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setSelectedFile(file)
    }
  }

  const handleUpload = async () => {
    if (!selectedFile) return

    setIsUploading(true)
    try {
      const formData = new FormData()
      formData.append('file', selectedFile)
      formData.append('propertyId', uploadForm.propertyId)
      formData.append('documentType', uploadForm.documentType)
      formData.append('description', uploadForm.description)
      formData.append('expiresAt', uploadForm.expiresAt)
      formData.append('tenancyId', uploadForm.tenancyId)
      formData.append('uploadedBy', 'temp-user-id') // This should come from authentication

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      })

      if (response.ok) {
        const data = await response.json()
        // Reset form
        setSelectedFile(null)
        setUploadForm({
          propertyId: '',
          documentType: 'OTHER',
          description: '',
          expiresAt: '',
          tenancyId: ''
        })
        setShowUploadDialog(false)
        // Show success message or refresh documents list
        alert('Document uploaded successfully!')
      } else {
        const error = await response.json()
        alert(`Upload failed: ${error.error}`)
      }
    } catch (error) {
      console.error('Error uploading document:', error)
      alert('Upload failed. Please try again.')
    } finally {
      setIsUploading(false)
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Building2 className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">Property Manager Pro</h1>
                <p className="text-sm text-muted-foreground">Document Storage</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="outline" size="sm">
                  <Home className="h-4 w-4 mr-2" />
                  Home
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button variant="outline" size="sm">Dashboard</Button>
              </Link>
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">Document Storage</h2>
            <p className="text-muted-foreground">Secure storage for all your property documents</p>
          </div>
          <Dialog open={showUploadDialog} onOpenChange={setShowUploadDialog}>
            <DialogTrigger asChild>
              <Button>
                <Upload className="h-4 w-4 mr-2" />
                Upload Document
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>Upload Document</DialogTitle>
                <DialogDescription>
                  Upload a new document to your property portfolio
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="file">Select File</Label>
                  <Input
                    id="file"
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                    className="mt-1"
                  />
                  {selectedFile && (
                    <p className="text-sm text-muted-foreground mt-1">
                      Selected: {selectedFile.name} ({(selectedFile.size / 1024 / 1024).toFixed(2)} MB)
                    </p>
                  )}
                </div>
                
                <div>
                  <Label htmlFor="propertyId">Property</Label>
                  <Select
                    value={uploadForm.propertyId}
                    onValueChange={(value) => setUploadForm({...uploadForm, propertyId: value})}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select property" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="prop1">123 Main Street, London</SelectItem>
                      <SelectItem value="prop2">456 Park Avenue, Manchester</SelectItem>
                      <SelectItem value="prop3">789 High Street, Birmingham</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="documentType">Document Type</Label>
                  <Select
                    value={uploadForm.documentType}
                    onValueChange={(value) => setUploadForm({...uploadForm, documentType: value})}
                  >
                    <SelectTrigger className="mt-1">
                      <SelectValue placeholder="Select document type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="LEASE_AGREEMENT">Lease Agreement</SelectItem>
                      <SelectItem value="GAS_SAFETY_CERTIFICATE">Gas Safety Certificate</SelectItem>
                      <SelectItem value="EPC_CERTIFICATE">EPC Certificate</SelectItem>
                      <SelectItem value="ELECTRICAL_SAFETY_CERTIFICATE">Electrical Safety Certificate</SelectItem>
                      <SelectItem value="INVENTORY_REPORT">Inventory Report</SelectItem>
                      <SelectItem value="DEPOSIT_PROTECTION_CERTIFICATE">Deposit Protection Certificate</SelectItem>
                      <SelectItem value="INSURANCE_DOCUMENT">Insurance Document</SelectItem>
                      <SelectItem value="OTHER">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="description">Description (optional)</Label>
                  <Textarea
                    id="description"
                    value={uploadForm.description}
                    onChange={(e) => setUploadForm({...uploadForm, description: e.target.value})}
                    placeholder="Document description..."
                    className="mt-1"
                  />
                </div>

                <div>
                  <Label htmlFor="expiresAt">Expiry Date (optional)</Label>
                  <Input
                    id="expiresAt"
                    type="date"
                    value={uploadForm.expiresAt}
                    onChange={(e) => setUploadForm({...uploadForm, expiresAt: e.target.value})}
                    className="mt-1"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setShowUploadDialog(false)}>
                  Cancel
                </Button>
                <Button onClick={handleUpload} disabled={!selectedFile || isUploading}>
                  {isUploading ? 'Uploading...' : 'Upload Document'}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Documents</p>
                  <p className="text-2xl font-bold">{documentStats.total}</p>
                </div>
                <FileText className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Starred</p>
                  <p className="text-2xl font-bold">{documentStats.starred}</p>
                </div>
                <Star className="h-8 w-8 text-yellow-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Expiring Soon</p>
                  <p className="text-2xl font-bold text-orange-600">{documentStats.expiringSoon}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Expired</p>
                  <p className="text-2xl font-bold text-red-600">{documentStats.expired}</p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search documents..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger className="w-full md:w-48">
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map((category) => (
                <SelectItem key={category.value} value={category.value}>
                  {category.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={selectedProperty} onValueChange={setSelectedProperty}>
            <SelectTrigger className="w-full md:w-64">
              <SelectValue placeholder="Select property" />
            </SelectTrigger>
            <SelectContent>
              {properties.map((property) => (
                <SelectItem key={property.value} value={property.value}>
                  {property.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="all">All Documents</TabsTrigger>
            <TabsTrigger value="certificates">Certificates</TabsTrigger>
            <TabsTrigger value="agreements">Agreements</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="starred">Starred</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <div className="grid gap-4">
              {filteredDocuments.map((doc) => {
                const expiryStatus = getExpiryStatus(doc.expiryDate)
                return (
                  <Card key={doc.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4 flex-1">
                          <div className="p-3 bg-blue-100 rounded-lg">
                            <FileText className="h-6 w-6 text-blue-600" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-semibold text-lg">{doc.name}</h3>
                              {doc.starred && <Star className="h-4 w-4 text-yellow-500 fill-current" />}
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                              <span className="flex items-center gap-1">
                                <Building2 className="h-4 w-4" />
                                {doc.property}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                Uploaded: {doc.uploadDate}
                              </span>
                              <span>{doc.size}</span>
                              <span>{doc.format}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant={getStatusColor(doc.status)}>
                                {doc.status}
                              </Badge>
                              {expiryStatus && (
                                <Badge variant={
                                  expiryStatus.status === "expired" ? "destructive" :
                                  expiryStatus.status === "expiring-soon" ? "destructive" :
                                  expiryStatus.status === "expiring" ? "default" : "secondary"
                                }>
                                  {expiryStatus.status === "expired" ? `Expired ${expiryStatus.days} days ago` :
                                   expiryStatus.status === "expiring-soon" ? `Expires in ${expiryStatus.days} days` :
                                   expiryStatus.status === "expiring" ? `Expires in ${expiryStatus.days} days` :
                                   "Valid"}
                                </Badge>
                              )}
                              {doc.tags.map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                          <Button variant="outline" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="certificates" className="space-y-4">
            <div className="grid gap-4">
              {filteredDocuments.filter(d => d.type === "certificate").map((doc) => {
                const expiryStatus = getExpiryStatus(doc.expiryDate)
                return (
                  <Card key={doc.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4 flex-1">
                          <div className="p-3 bg-green-100 rounded-lg">
                            <FileText className="h-6 w-6 text-green-600" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-semibold text-lg">{doc.name}</h3>
                              {doc.starred && <Star className="h-4 w-4 text-yellow-500 fill-current" />}
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                              <span className="flex items-center gap-1">
                                <Building2 className="h-4 w-4" />
                                {doc.property}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                Uploaded: {doc.uploadDate}
                              </span>
                              <span>{doc.size}</span>
                              <span>{doc.format}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant={getStatusColor(doc.status)}>
                                {doc.status}
                              </Badge>
                              {expiryStatus && (
                                <Badge variant={
                                  expiryStatus.status === "expired" ? "destructive" :
                                  expiryStatus.status === "expiring-soon" ? "destructive" :
                                  expiryStatus.status === "expiring" ? "default" : "secondary"
                                }>
                                  {expiryStatus.status === "expired" ? `Expired ${expiryStatus.days} days ago` :
                                   expiryStatus.status === "expiring-soon" ? `Expires in ${expiryStatus.days} days` :
                                   expiryStatus.status === "expiring" ? `Expires in ${expiryStatus.days} days` :
                                   "Valid"}
                                </Badge>
                              )}
                              {doc.tags.map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                          <Button variant="outline" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="agreements" className="space-y-4">
            <div className="grid gap-4">
              {filteredDocuments.filter(d => d.type === "agreement").map((doc) => {
                const expiryStatus = getExpiryStatus(doc.expiryDate)
                return (
                  <Card key={doc.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4 flex-1">
                          <div className="p-3 bg-purple-100 rounded-lg">
                            <FileText className="h-6 w-6 text-purple-600" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-semibold text-lg">{doc.name}</h3>
                              {doc.starred && <Star className="h-4 w-4 text-yellow-500 fill-current" />}
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                              <span className="flex items-center gap-1">
                                <Building2 className="h-4 w-4" />
                                {doc.property}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                Uploaded: {doc.uploadDate}
                              </span>
                              <span>{doc.size}</span>
                              <span>{doc.format}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant={getStatusColor(doc.status)}>
                                {doc.status}
                              </Badge>
                              {expiryStatus && (
                                <Badge variant={
                                  expiryStatus.status === "expired" ? "destructive" :
                                  expiryStatus.status === "expiring-soon" ? "destructive" :
                                  expiryStatus.status === "expiring" ? "default" : "secondary"
                                }>
                                  {expiryStatus.status === "expired" ? `Expired ${expiryStatus.days} days ago` :
                                   expiryStatus.status === "expiring-soon" ? `Expires in ${expiryStatus.days} days` :
                                   expiryStatus.status === "expiring" ? `Expires in ${expiryStatus.days} days` :
                                   "Valid"}
                                </Badge>
                              )}
                              {doc.tags.map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                          <Button variant="outline" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="reports" className="space-y-4">
            <div className="grid gap-4">
              {filteredDocuments.filter(d => d.type === "report" || d.type === "assessment").map((doc) => {
                const expiryStatus = getExpiryStatus(doc.expiryDate)
                return (
                  <Card key={doc.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4 flex-1">
                          <div className="p-3 bg-orange-100 rounded-lg">
                            <FileText className="h-6 w-6 text-orange-600" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-semibold text-lg">{doc.name}</h3>
                              {doc.starred && <Star className="h-4 w-4 text-yellow-500 fill-current" />}
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                              <span className="flex items-center gap-1">
                                <Building2 className="h-4 w-4" />
                                {doc.property}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                Uploaded: {doc.uploadDate}
                              </span>
                              <span>{doc.size}</span>
                              <span>{doc.format}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant={getStatusColor(doc.status)}>
                                {doc.status}
                              </Badge>
                              {expiryStatus && (
                                <Badge variant={
                                  expiryStatus.status === "expired" ? "destructive" :
                                  expiryStatus.status === "expiring-soon" ? "destructive" :
                                  expiryStatus.status === "expiring" ? "default" : "secondary"
                                }>
                                  {expiryStatus.status === "expired" ? `Expired ${expiryStatus.days} days ago` :
                                   expiryStatus.status === "expiring-soon" ? `Expires in ${expiryStatus.days} days` :
                                   expiryStatus.status === "expiring" ? `Expires in ${expiryStatus.days} days` :
                                   "Valid"}
                                </Badge>
                              )}
                              {doc.tags.map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                          <Button variant="outline" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>

          <TabsContent value="starred" className="space-y-4">
            <div className="grid gap-4">
              {filteredDocuments.filter(d => d.starred).map((doc) => {
                const expiryStatus = getExpiryStatus(doc.expiryDate)
                return (
                  <Card key={doc.id} className="hover:shadow-md transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-4 flex-1">
                          <div className="p-3 bg-yellow-100 rounded-lg">
                            <Star className="h-6 w-6 text-yellow-600 fill-current" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h3 className="font-semibold text-lg">{doc.name}</h3>
                              <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            </div>
                            <div className="flex items-center gap-4 text-sm text-muted-foreground mb-2">
                              <span className="flex items-center gap-1">
                                <Building2 className="h-4 w-4" />
                                {doc.property}
                              </span>
                              <span className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                Uploaded: {doc.uploadDate}
                              </span>
                              <span>{doc.size}</span>
                              <span>{doc.format}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant={getStatusColor(doc.status)}>
                                {doc.status}
                              </Badge>
                              {expiryStatus && (
                                <Badge variant={
                                  expiryStatus.status === "expired" ? "destructive" :
                                  expiryStatus.status === "expiring-soon" ? "destructive" :
                                  expiryStatus.status === "expiring" ? "default" : "secondary"
                                }>
                                  {expiryStatus.status === "expired" ? `Expired ${expiryStatus.days} days ago` :
                                   expiryStatus.status === "expiring-soon" ? `Expires in ${expiryStatus.days} days` :
                                   expiryStatus.status === "expiring" ? `Expires in ${expiryStatus.days} days` :
                                   "Valid"}
                                </Badge>
                              )}
                              {doc.tags.map((tag) => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button variant="outline" size="sm">
                            <Eye className="h-4 w-4 mr-1" />
                            View
                          </Button>
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                          <Button variant="outline" size="sm">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}