'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { 
  Building2, 
  Wrench, 
  Plus, 
  Search,
  Home,
  Bell,
  Settings,
  Calendar,
  Clock,
  DollarSign,
  User,
  CheckCircle,
  AlertTriangle,
  Filter,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2,
  Phone,
  Mail,
  Star,
  Camera,
  Paperclip
} from "lucide-react"

export default function Maintenance() {
  const [activeTab, setActiveTab] = useState("requests")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedPriority, setSelectedPriority] = useState("all")
  const [selectedProperty, setSelectedProperty] = useState("all")

  // Mock maintenance data
  const maintenanceRequests = [
    {
      id: 1,
      title: "Plumbing Issue - Leaking Tap",
      description: "Kitchen tap is leaking continuously, needs immediate repair",
      property: "123 Main Street, London",
      tenant: "John Smith",
      category: "plumbing",
      priority: "high",
      status: "in-progress",
      reportedDate: "2024-01-15",
      estimatedCost: 150,
      actualCost: null,
      assignedTo: "ABC Plumbing Services",
      dueDate: "2024-01-20",
      completedDate: null,
      images: ["tap-leak.jpg"],
      documents: [],
      tags: ["plumbing", "urgent", "kitchen"]
    },
    {
      id: 2,
      title: "Heating System Not Working",
      description: "Central heating system has stopped working during cold weather",
      property: "789 High Street, Birmingham",
      tenant: "Sarah Johnson",
      category: "heating",
      priority: "high",
      status: "pending",
      reportedDate: "2024-01-12",
      estimatedCost: 300,
      actualCost: null,
      assignedTo: null,
      dueDate: "2024-01-18",
      completedDate: null,
      images: ["heating-unit.jpg"],
      documents: [],
      tags: ["heating", "urgent", "winter"]
    },
    {
      id: 3,
      title: "Broken Window Pane",
      description: "Bedroom window cracked due to storm damage",
      property: "456 Park Avenue, Manchester",
      tenant: "Mike Wilson",
      category: "general",
      priority: "medium",
      status: "completed",
      reportedDate: "2024-01-10",
      estimatedCost: 200,
      actualCost: 180,
      assignedTo: "Quick Fix Glass",
      dueDate: "2024-01-15",
      completedDate: "2024-01-14",
      images: ["broken-window.jpg"],
      documents: ["invoice.pdf"],
      tags: ["window", "storm", "completed"]
    },
    {
      id: 4,
      title: "Electrical Socket Not Working",
      description: "Living room electrical socket not functioning, needs inspection",
      property: "123 Main Street, London",
      tenant: "John Smith",
      category: "electrical",
      priority: "medium",
      status: "scheduled",
      reportedDate: "2024-01-08",
      estimatedCost: 100,
      actualCost: null,
      assignedTo: "Safe Electric Co",
      dueDate: "2024-01-22",
      completedDate: null,
      images: [],
      documents: [],
      tags: ["electrical", "safety", "living-room"]
    },
    {
      id: 5,
      title: "Garden Fence Repair",
      description: "Back garden fence panels damaged and need replacement",
      property: "456 Park Avenue, Manchester",
      tenant: "Mike Wilson",
      category: "external",
      priority: "low",
      status: "pending",
      reportedDate: "2024-01-05",
      estimatedCost: 400,
      actualCost: null,
      assignedTo: null,
      dueDate: "2024-02-01",
      completedDate: null,
      images: ["fence-damage.jpg"],
      documents: [],
      tags: ["fence", "garden", "external"]
    }
  ]

  const contractors = [
    {
      id: 1,
      name: "ABC Plumbing Services",
      category: "plumbing",
      rating: 4.8,
      phone: "+44 20 1234 5678",
      email: "contact@abcplumbing.co.uk",
      totalJobs: 15,
      completedJobs: 15,
      averageCost: 145,
      responseTime: "2 hours",
      specialties: ["plumbing", "heating", "boilers"]
    },
    {
      id: 2,
      name: "Quick Fix Glass",
      category: "general",
      rating: 4.6,
      phone: "+44 16 1234 5678",
      email: "info@quickfixglass.co.uk",
      totalJobs: 8,
      completedJobs: 8,
      averageCost: 175,
      responseTime: "4 hours",
      specialties: ["glass", "windows", "glazing"]
    },
    {
      id: 3,
      name: "Safe Electric Co",
      category: "electrical",
      rating: 4.9,
      phone: "+44 20 8765 4321",
      email: "hello@safeelectric.co.uk",
      totalJobs: 22,
      completedJobs: 22,
      averageCost: 95,
      responseTime: "1 hour",
      specialties: ["electrical", "lighting", "safety inspections"]
    }
  ]

  const maintenanceStats = {
    total: maintenanceRequests.length,
    pending: maintenanceRequests.filter(r => r.status === "pending").length,
    inProgress: maintenanceRequests.filter(r => r.status === "in-progress").length,
    completed: maintenanceRequests.filter(r => r.status === "completed").length,
    scheduled: maintenanceRequests.filter(r => r.status === "scheduled").length,
    totalCost: maintenanceRequests.filter(r => r.actualCost).reduce((sum, r) => sum + (r.actualCost || 0), 0),
    avgResponseTime: "2.5 days"
  }

  const categories = [
    { value: "all", label: "All Categories" },
    { value: "plumbing", label: "Plumbing" },
    { value: "electrical", label: "Electrical" },
    { value: "heating", label: "Heating" },
    { value: "general", label: "General" },
    { value: "external", label: "External" }
  ]

  const properties = [
    { value: "all", label: "All Properties" },
    { value: "123 Main Street, London", label: "123 Main Street, London" },
    { value: "456 Park Avenue, Manchester", label: "456 Park Avenue, Manchester" },
    { value: "789 High Street, Birmingham", label: "789 High Street, Birmingham" }
  ]

  const statuses = [
    { value: "all", label: "All Statuses" },
    { value: "pending", label: "Pending" },
    { value: "scheduled", label: "Scheduled" },
    { value: "in-progress", label: "In Progress" },
    { value: "completed", label: "Completed" }
  ]

  const priorities = [
    { value: "all", label: "All Priorities" },
    { value: "high", label: "High" },
    { value: "medium", label: "Medium" },
    { value: "low", label: "Low" }
  ]

  const filteredRequests = maintenanceRequests.filter(request => {
    const matchesSearch = request.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         request.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         request.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
    const matchesStatus = selectedStatus === "all" || request.status === selectedStatus
    const matchesPriority = selectedPriority === "all" || request.priority === selectedPriority
    const matchesProperty = selectedProperty === "all" || request.property === selectedProperty
    
    return matchesSearch && matchesStatus && matchesPriority && matchesProperty
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "secondary"
      case "scheduled": return "default"
      case "in-progress": return "default"
      case "completed": return "default"
      default: return "secondary"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "destructive"
      case "medium": return "default"
      case "low": return "secondary"
      default: return "secondary"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "pending": return <Clock className="h-4 w-4" />
      case "scheduled": return <Calendar className="h-4 w-4" />
      case "in-progress": return <Wrench className="h-4 w-4" />
      case "completed": return <CheckCircle className="h-4 w-4" />
      default: return <Clock className="h-4 w-4" />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Building2 className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">Property Manager Pro</h1>
                <p className="text-sm text-muted-foreground">Maintenance Portal</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="outline" size="sm">
                  <Home className="h-4 w-4 mr-2" />
                  Home
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button variant="outline" size="sm">Dashboard</Button>
              </Link>
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">Maintenance Portal</h2>
            <p className="text-muted-foreground">Track and manage property maintenance requests</p>
          </div>
          <Button>
            <Plus className="h-4 w-4 mr-2" />
            New Request
          </Button>
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total</p>
                  <p className="text-2xl font-bold">{maintenanceStats.total}</p>
                </div>
                <Wrench className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Pending</p>
                  <p className="text-2xl font-bold text-orange-600">{maintenanceStats.pending}</p>
                </div>
                <Clock className="h-8 w-8 text-orange-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">In Progress</p>
                  <p className="text-2xl font-bold text-blue-600">{maintenanceStats.inProgress}</p>
                </div>
                <Wrench className="h-8 w-8 text-blue-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Completed</p>
                  <p className="text-2xl font-bold text-green-600">{maintenanceStats.completed}</p>
                </div>
                <CheckCircle className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Total Cost</p>
                  <p className="text-2xl font-bold">£{maintenanceStats.totalCost}</p>
                </div>
                <DollarSign className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Avg Response</p>
                  <p className="text-2xl font-bold">{maintenanceStats.avgResponseTime}</p>
                </div>
                <Clock className="h-8 w-8 text-purple-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <div className="flex flex-col md:flex-row gap-4 mb-6">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search maintenance requests..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          <Select value={selectedStatus} onValueChange={setSelectedStatus}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              {statuses.map((status) => (
                <SelectItem key={status.value} value={status.value}>
                  {status.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={selectedPriority} onValueChange={setSelectedPriority}>
            <SelectTrigger className="w-full md:w-40">
              <SelectValue placeholder="Priority" />
            </SelectTrigger>
            <SelectContent>
              {priorities.map((priority) => (
                <SelectItem key={priority.value} value={priority.value}>
                  {priority.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={selectedProperty} onValueChange={setSelectedProperty}>
            <SelectTrigger className="w-full md:w-64">
              <SelectValue placeholder="Property" />
            </SelectTrigger>
            <SelectContent>
              {properties.map((property) => (
                <SelectItem key={property.value} value={property.value}>
                  {property.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="requests">Maintenance Requests</TabsTrigger>
            <TabsTrigger value="contractors">Contractors</TabsTrigger>
            <TabsTrigger value="schedule">Schedule</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="requests" className="space-y-4">
            <div className="grid gap-4">
              {filteredRequests.map((request) => (
                <Card key={request.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4 flex-1">
                        <div className={`p-3 rounded-lg ${
                          request.priority === 'high' ? 'bg-red-100' :
                          request.priority === 'medium' ? 'bg-yellow-100' : 'bg-green-100'
                        }`}>
                          {getStatusIcon(request.status)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold text-lg">{request.title}</h3>
                            <Badge variant={getPriorityColor(request.priority)}>
                              {request.priority}
                            </Badge>
                            <Badge variant={getStatusColor(request.status)}>
                              {request.status.replace('-', ' ')}
                            </Badge>
                          </div>
                          <p className="text-muted-foreground mb-3">{request.description}</p>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Property:</span>
                              <p className="font-medium">{request.property}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Tenant:</span>
                              <p className="font-medium">{request.tenant}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Reported:</span>
                              <p className="font-medium">{request.reportedDate}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Due Date:</span>
                              <p className="font-medium">{request.dueDate}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Assigned To:</span>
                              <p className="font-medium">{request.assignedTo || 'Unassigned'}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Cost:</span>
                              <p className="font-medium">
                                £{request.actualCost || request.estimatedCost || 'TBD'}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 mt-3">
                            {request.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                            {request.images.length > 0 && (
                              <Badge variant="outline" className="text-xs">
                                <Camera className="h-3 w-3 mr-1" />
                                {request.images.length} images
                              </Badge>
                            )}
                            {request.documents.length > 0 && (
                              <Badge variant="outline" className="text-xs">
                                <Paperclip className="h-3 w-3 mr-1" />
                                {request.documents.length} documents
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                        {request.status === 'pending' && (
                          <Button size="sm">Assign</Button>
                        )}
                        {request.status === 'in-progress' && (
                          <Button size="sm">Complete</Button>
                        )}
                        <Button variant="outline" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="contractors" className="space-y-4">
            <div className="grid gap-4">
              {contractors.map((contractor) => (
                <Card key={contractor.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start gap-4 flex-1">
                        <div className="p-3 bg-blue-100 rounded-lg">
                          <User className="h-6 w-6 text-blue-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold text-lg">{contractor.name}</h3>
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 text-yellow-500 fill-current" />
                              <span className="text-sm font-medium">{contractor.rating}</span>
                            </div>
                            <Badge variant="outline">{contractor.category}</Badge>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm mb-3">
                            <div className="flex items-center gap-2">
                              <Phone className="h-4 w-4 text-muted-foreground" />
                              <span>{contractor.phone}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Mail className="h-4 w-4 text-muted-foreground" />
                              <span>{contractor.email}</span>
                            </div>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Total Jobs:</span>
                              <p className="font-medium">{contractor.totalJobs}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Completed:</span>
                              <p className="font-medium text-green-600">{contractor.completedJobs}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Avg Cost:</span>
                              <p className="font-medium">£{contractor.averageCost}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Response Time:</span>
                              <p className="font-medium">{contractor.responseTime}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 mt-3">
                            {contractor.specialties.map((specialty) => (
                              <Badge key={specialty} variant="outline" className="text-xs">
                                {specialty}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4 mr-1" />
                          View Profile
                        </Button>
                        <Button size="sm">Assign Job</Button>
                        <Button variant="outline" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="schedule" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Maintenance Schedule</CardTitle>
                <CardDescription>Calendar view of upcoming and ongoing maintenance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">This Week</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                          <span className="text-sm">Plumbing Repair - Today</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          <span className="text-sm">Electrical Work - Tomorrow</span>
                        </div>
                      </div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">Next Week</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                          <span className="text-sm">Heating System - Monday</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <span className="text-sm">Window Repair - Wednesday</span>
                        </div>
                      </div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <h4 className="font-medium mb-2">This Month</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
                          <span className="text-sm">Garden Fence - End of month</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                          <span className="text-sm">Regular Inspection - Scheduled</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Maintenance by Category</CardTitle>
                  <CardDescription>Breakdown of maintenance requests by type</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Plumbing</span>
                      <div className="flex items-center gap-2">
                        <Progress value={20} className="w-20" />
                        <span className="text-sm">20%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Electrical</span>
                      <div className="flex items-center gap-2">
                        <Progress value={20} className="w-20" />
                        <span className="text-sm">20%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Heating</span>
                      <div className="flex items-center gap-2">
                        <Progress value={20} className="w-20" />
                        <span className="text-sm">20%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>General</span>
                      <div className="flex items-center gap-2">
                        <Progress value={20} className="w-20" />
                        <span className="text-sm">20%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>External</span>
                      <div className="flex items-center gap-2">
                        <Progress value={20} className="w-20" />
                        <span className="text-sm">20%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Contractor Performance</CardTitle>
                  <CardDescription>Rating and completion statistics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {contractors.map((contractor) => (
                      <div key={contractor.id} className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="font-medium">{contractor.name}</span>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-yellow-500 fill-current" />
                            <span className="text-sm">{contractor.rating}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-medium">
                            {contractor.completedJobs}/{contractor.totalJobs} jobs
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {contractor.responseTime} response
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}