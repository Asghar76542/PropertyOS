'use client'

import Link from 'next/link'
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Building2, Users, TrendingUp, Shield, FileText, Wrench, BarChart3, CreditCard, Bot, CheckCircle, ArrowRight, Star, Sparkles } from "lucide-react"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Navigation */}
      <nav className="border-b border-slate-200/60 bg-white/80 backdrop-blur-xl supports-[backdrop-filter]:bg-white/60 sticky top-0 z-50">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full blur opacity-25"></div>
                <div className="relative bg-gradient-to-r from-blue-600 to-purple-600 p-0.5 rounded-full">
                  <div className="bg-white rounded-full p-2">
                    <Building2 className="h-8 w-8 text-transparent bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text" />
                  </div>
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-slate-900 to-slate-700 bg-clip-text text-transparent">
                  Property Manager Pro
                </h1>
                <p className="text-sm text-slate-500 font-medium">Professional Property Management</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/dashboard-test">
                <Button variant="outline" className="border-slate-200 text-slate-700 hover:bg-slate-50 hover:text-slate-900 hover:border-slate-300 font-medium">
                  Test Dashboard
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button variant="outline" className="border-slate-200 text-slate-700 hover:bg-slate-50 hover:text-slate-900 hover:border-slate-300 font-medium">
                  Dashboard
                </Button>
              </Link>
              <Link href="/tenant-dashboard">
                <Button variant="outline" className="border-slate-200 text-slate-700 hover:bg-slate-50 hover:text-slate-900 hover:border-slate-300 font-medium">
                  Tenant Portal
                </Button>
              </Link>
              <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white font-medium shadow-lg hover:shadow-xl transition-all duration-300">
                Get Started
              </Button>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900"></div>
        <div className="absolute inset-0 opacity-20">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, rgba(255,255,255,0.1) 0%, transparent 50%), 
                             radial-gradient(circle at 75% 75%, rgba(255,255,255,0.1) 0%, transparent 50%)`,
            backgroundSize: '200px 200px'
          }}></div>
        </div>
        
        {/* Animated Elements */}
        <div className="absolute top-20 left-10 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-72 h-72 bg-blue-500 rounded-full mix-blend-multiply filter blur-xl opacity-20 animate-pulse animation-delay-2000"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-6xl mx-auto text-center">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-full px-6 py-3 mb-8">
              <Sparkles className="h-5 w-5 text-yellow-300" />
              <Badge variant="secondary" className="bg-transparent text-white border-transparent text-sm font-medium">
                Property Tech Platform
              </Badge>
              <Star className="h-5 w-5 text-yellow-300" />
            </div>
            
            {/* Main Heading */}
            <h1 className="text-5xl lg:text-7xl xl:text-8xl font-bold mb-6 leading-tight">
              <span className="block text-white mb-4">Empowering Landlords with</span>
              <span className="block bg-gradient-to-r from-yellow-300 via-orange-300 to-pink-300 bg-clip-text text-transparent">
                Professional Tools
              </span>
            </h1>
            
            {/* Subtitle */}
            <p className="text-xl lg:text-2xl text-white/80 mb-12 max-w-3xl mx-auto leading-relaxed font-light">
              Professional property management tools at a fraction of traditional costs, 
              while providing tenants with a seamless rental experience.
            </p>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-6 justify-center mb-20">
              <Button size="lg" className="group text-lg px-10 py-4 bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-slate-900 font-bold shadow-2xl hover:shadow-yellow-500/25 transition-all duration-300 hover:scale-105">
                Get Started for £10/month
                <ArrowRight className="ml-3 h-6 w-6 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button variant="outline" size="lg" className="group text-lg px-10 py-4 bg-white/10 text-white border-white/30 hover:bg-white/20 hover:border-white/50 backdrop-blur-md font-medium shadow-lg hover:shadow-white/10 transition-all duration-300 hover:scale-105">
                View Demo
                <div className="ml-3 w-6 h-6 rounded-full border-2 border-white/50 flex items-center justify-center">
                  <div className="w-2 h-2 bg-white rounded-full"></div>
                </div>
              </Button>
            </div>
            
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-16">
              <div className="group relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-green-400 to-emerald-500 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
                <div className="relative bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                  <div className="text-5xl font-bold text-green-300 mb-3">60%</div>
                  <div className="text-white/90 font-medium">Cost Savings vs Traditional Agents</div>
                  <div className="text-white/60 text-sm mt-2">Average savings across all services</div>
                </div>
              </div>
              
              <div className="group relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
                <div className="relative bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                  <div className="text-5xl font-bold text-blue-300 mb-3">£10</div>
                  <div className="text-white/90 font-medium">Monthly Subscription</div>
                  <div className="text-white/60 text-sm mt-2">All-inclusive property management</div>
                </div>
              </div>
              
              <div className="group relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-purple-400 to-pink-500 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
                <div className="relative bg-white/10 backdrop-blur-md rounded-2xl p-8 border border-white/20">
                  <div className="text-5xl font-bold text-purple-300 mb-3">5%</div>
                  <div className="text-white/90 font-medium">Payment Processing Fee</div>
                  <div className="text-white/60 text-sm mt-2">Secure automated rent collection</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        {/* Bottom Gradient */}
        <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-slate-50 to-transparent"></div>
      </section>

      {/* Features Section */}
      <section className="py-32 bg-gradient-to-b from-slate-50 to-white">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(45deg, #e2e8f0 25%, transparent 25%), 
                             linear-gradient(-45deg, #e2e8f0 25%, transparent 25%), 
                             linear-gradient(45deg, transparent 75%, #e2e8f0 75%), 
                             linear-gradient(-45deg, transparent 75%, #e2e8f0 75%)`,
            backgroundSize: '50px 50px',
            backgroundPosition: '0 0, 0 25px, 25px -25px, -25px 0px'
          }}></div>
        </div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-20">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-blue-100 to-purple-100 rounded-full px-6 py-2 mb-6">
              <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
              <span className="text-sm font-semibold text-blue-900">FEATURES</span>
            </div>
            <h2 className="text-4xl lg:text-5xl xl:text-6xl font-bold mb-6 bg-gradient-to-r from-slate-900 via-blue-900 to-purple-900 bg-clip-text text-transparent leading-tight">
              Everything You Need to Manage Properties Efficiently
            </h2>
            <p className="text-xl lg:text-2xl text-slate-600 max-w-3xl mx-auto leading-relaxed font-light">
              Comprehensive tools designed for modern landlords who want full control without the hassle.
            </p>
          </div>
          
          {/* First Row of Features */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-blue-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <Card className="relative bg-white rounded-2xl border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 to-blue-600"></div>
                <CardHeader className="text-center pb-6 pt-8">
                  <div className="relative mx-auto mb-6">
                    <div className="absolute -inset-2 bg-gradient-to-r from-blue-400 to-blue-600 rounded-full blur opacity-30"></div>
                    <div className="relative w-20 h-20 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                      <Shield className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-slate-900 mb-2">Compliance Dashboard</CardTitle>
                  <CardDescription className="text-slate-600 text-base leading-relaxed">
                    Stay compliant with up-to-date regulations and requirements
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-8 pb-8">
                  <ul className="space-y-4">
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Real-time compliance monitoring</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Automated deadline reminders</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Regulation updates</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-400 to-purple-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <Card className="relative bg-white rounded-2xl border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-purple-400 to-purple-600"></div>
                <CardHeader className="text-center pb-6 pt-8">
                  <div className="relative mx-auto mb-6">
                    <div className="absolute -inset-2 bg-gradient-to-r from-purple-400 to-purple-600 rounded-full blur opacity-30"></div>
                    <div className="relative w-20 h-20 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                      <Bot className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-slate-900 mb-2">AI Regulations Advisor</CardTitle>
                  <CardDescription className="text-slate-600 text-base leading-relaxed">
                    Get intelligent guidance on complex property regulations
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-8 pb-8">
                  <ul className="space-y-4">
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Smart compliance recommendations</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Risk assessment alerts</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Customized advice</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-green-400 to-green-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <Card className="relative bg-white rounded-2xl border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-green-400 to-green-600"></div>
                <CardHeader className="text-center pb-6 pt-8">
                  <div className="relative mx-auto mb-6">
                    <div className="absolute -inset-2 bg-gradient-to-r from-green-400 to-green-600 rounded-full blur opacity-30"></div>
                    <div className="relative w-20 h-20 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                      <FileText className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-slate-900 mb-2">Document Storage</CardTitle>
                  <CardDescription className="text-slate-600 text-base leading-relaxed">
                    Secure, organized storage for all property documents
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-8 pb-8">
                  <ul className="space-y-4">
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Cloud-based secure storage</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Easy document retrieval</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Template library</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Second row of features */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-orange-400 to-orange-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <Card className="relative bg-white rounded-2xl border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-orange-400 to-orange-600"></div>
                <CardHeader className="text-center pb-6 pt-8">
                  <div className="relative mx-auto mb-6">
                    <div className="absolute -inset-2 bg-gradient-to-r from-orange-400 to-orange-600 rounded-full blur opacity-30"></div>
                    <div className="relative w-20 h-20 bg-gradient-to-br from-orange-500 to-orange-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                      <Wrench className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-slate-900 mb-2">Maintenance Portal</CardTitle>
                  <CardDescription className="text-slate-600 text-base leading-relaxed">
                    Streamlined maintenance request management
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-8 pb-8">
                  <ul className="space-y-4">
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Track maintenance requests</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Contractor management</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Cost tracking</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-indigo-400 to-indigo-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <Card className="relative bg-white rounded-2xl border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-400 to-indigo-600"></div>
                <CardHeader className="text-center pb-6 pt-8">
                  <div className="relative mx-auto mb-6">
                    <div className="absolute -inset-2 bg-gradient-to-r from-indigo-400 to-indigo-600 rounded-full blur opacity-30"></div>
                    <div className="relative w-20 h-20 bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                      <BarChart3 className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-slate-900 mb-2">Reporting Tools</CardTitle>
                  <CardDescription className="text-slate-600 text-base leading-relaxed">
                    Comprehensive analytics and reporting
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-8 pb-8">
                  <ul className="space-y-4">
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Financial performance reports</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Occupancy analytics</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Custom report builder</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-pink-400 to-pink-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <Card className="relative bg-white rounded-2xl border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 overflow-hidden">
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-pink-400 to-pink-600"></div>
                <CardHeader className="text-center pb-6 pt-8">
                  <div className="relative mx-auto mb-6">
                    <div className="absolute -inset-2 bg-gradient-to-r from-pink-400 to-pink-600 rounded-full blur opacity-30"></div>
                    <div className="relative w-20 h-20 bg-gradient-to-br from-pink-500 to-pink-600 rounded-2xl flex items-center justify-center mx-auto shadow-lg">
                      <CreditCard className="h-10 w-10 text-white" />
                    </div>
                  </div>
                  <CardTitle className="text-2xl font-bold text-slate-900 mb-2">Payment Processing</CardTitle>
                  <CardDescription className="text-slate-600 text-base leading-relaxed">
                    Secure rent collection and processing
                  </CardDescription>
                </CardHeader>
                <CardContent className="px-8 pb-8">
                  <ul className="space-y-4">
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Automated rent collection</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Multiple payment methods</span>
                    </li>
                    <li className="flex items-center gap-3">
                      <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <CheckCircle className="h-3 w-3 text-green-600" />
                      </div>
                      <span className="text-slate-700 font-medium">Late payment alerts</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Market Opportunity Section */}
      <section className="py-32 bg-gradient-to-br from-slate-100 via-white to-slate-100 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 20% 80%, rgba(59, 130, 246, 0.3) 0%, transparent 50%), 
                             radial-gradient(circle at 80% 20%, rgba(147, 51, 234, 0.3) 0%, transparent 50%), 
                             radial-gradient(circle at 40% 40%, rgba(236, 72, 153, 0.2) 0%, transparent 50%)`,
            backgroundSize: '300px 300px'
          }}></div>
        </div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-20">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-green-100 to-blue-100 rounded-full px-6 py-2 mb-6">
              <div className="w-2 h-2 bg-green-600 rounded-full animate-pulse"></div>
              <span className="text-sm font-semibold text-green-900">MARKET OPPORTUNITY</span>
            </div>
            <h2 className="text-4xl lg:text-5xl xl:text-6xl font-bold mb-6 bg-gradient-to-r from-green-600 via-blue-600 to-purple-600 bg-clip-text text-transparent leading-tight">
              Market Opportunity
            </h2>
            <p className="text-xl lg:text-2xl text-slate-600 max-w-3xl mx-auto leading-relaxed font-light">
              Tap into the growing UK property management market with our innovative platform.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-green-400 to-emerald-500 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <div className="relative bg-white rounded-2xl shadow-xl p-8 border border-green-100 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
                <div className="flex flex-col items-center text-center">
                  <div className="relative mb-6">
                    <div className="absolute -inset-3 bg-green-100 rounded-full blur opacity-30"></div>
                    <div className="relative w-24 h-24 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center shadow-lg">
                      <Users className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <div className="text-6xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent mb-3">2.6M</div>
                  <div className="text-xl font-semibold text-slate-800 mb-2">UK Landlords</div>
                  <div className="text-slate-600 leading-relaxed">
                    Target market of DIY landlords seeking cost-effective management solutions
                  </div>
                </div>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-cyan-500 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <div className="relative bg-white rounded-2xl shadow-xl p-8 border border-blue-100 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
                <div className="flex flex-col items-center text-center">
                  <div className="relative mb-6">
                    <div className="absolute -inset-3 bg-blue-100 rounded-full blur opacity-30"></div>
                    <div className="relative w-24 h-24 bg-gradient-to-br from-blue-400 to-cyan-500 rounded-full flex items-center justify-center shadow-lg">
                      <TrendingUp className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <div className="text-6xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent mb-3">£4.2B</div>
                  <div className="text-xl font-semibold text-slate-800 mb-2">UK Property Management Market</div>
                  <div className="text-slate-600 leading-relaxed">
                    Massive market opportunity with growing demand for digital solutions
                  </div>
                </div>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-purple-400 to-pink-500 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <div className="relative bg-white rounded-2xl shadow-xl p-8 border border-purple-100 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
                <div className="flex flex-col items-center text-center">
                  <div className="relative mb-6">
                    <div className="absolute -inset-3 bg-purple-100 rounded-full blur opacity-30"></div>
                    <div className="relative w-24 h-24 bg-gradient-to-br from-purple-400 to-pink-500 rounded-full flex items-center justify-center shadow-lg">
                      <Building2 className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <div className="text-6xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent mb-3">60%</div>
                  <div className="text-xl font-semibold text-slate-800 mb-2">Cost Savings</div>
                  <div className="text-slate-600 leading-relaxed">
                    Significant cost reduction compared to traditional letting agents
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Revenue Model Section */}
      <section className="py-32 bg-gradient-to-br from-white via-slate-50 to-white relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-3">
          <div className="absolute inset-0" style={{
            backgroundImage: `conic-gradient(from 45deg at 50% 50%, rgba(147, 51, 234, 0.1) 0deg, transparent 90deg, rgba(59, 130, 246, 0.1) 180deg, transparent 270deg, rgba(236, 72, 153, 0.1) 360deg)`,
            backgroundSize: '400px 400px'
          }}></div>
        </div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-20">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-100 to-pink-100 rounded-full px-6 py-2 mb-6">
              <div className="w-2 h-2 bg-purple-600 rounded-full animate-pulse"></div>
              <span className="text-sm font-semibold text-purple-900">REVENUE MODEL</span>
            </div>
            <h2 className="text-4xl lg:text-5xl xl:text-6xl font-bold mb-6 bg-gradient-to-r from-purple-600 via-pink-600 to-red-600 bg-clip-text text-transparent leading-tight">
              Revenue Model
            </h2>
            <p className="text-xl lg:text-2xl text-slate-600 max-w-3xl mx-auto leading-relaxed font-light">
              Flexible pricing structure designed for maximum value and scalability.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <div className="group relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-blue-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
                <div className="relative bg-white rounded-2xl shadow-xl p-8 border border-blue-100 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
                  <div className="flex items-start gap-6">
                    <div className="relative flex-shrink-0">
                      <div className="absolute -inset-2 bg-blue-100 rounded-2xl blur opacity-30"></div>
                      <div className="relative w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <Building2 className="h-8 w-8 text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-slate-900 mb-2">Core Subscription</h3>
                      <p className="text-slate-600 mb-4 leading-relaxed">Essential property management tools</p>
                      <div className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-blue-800 bg-clip-text text-transparent mb-3">
                        £10<span className="text-xl font-normal text-slate-600">/month</span>
                      </div>
                      <p className="text-slate-600 text-sm leading-relaxed">
                        Access to all core property management features including compliance dashboard, 
                        AI regulations advisor, document storage, maintenance portal, and reporting tools.
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="group relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-pink-400 to-pink-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
                <div className="relative bg-white rounded-2xl shadow-xl p-8 border border-pink-100 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
                  <div className="flex items-start gap-6">
                    <div className="relative flex-shrink-0">
                      <div className="absolute -inset-2 bg-pink-100 rounded-2xl blur opacity-30"></div>
                      <div className="relative w-16 h-16 bg-gradient-to-br from-pink-500 to-pink-600 rounded-2xl flex items-center justify-center shadow-lg">
                        <CreditCard className="h-8 w-8 text-white" />
                      </div>
                    </div>
                    <div className="flex-1">
                      <h3 className="text-2xl font-bold text-slate-900 mb-2">Payment Processing</h3>
                      <p className="text-slate-600 mb-4 leading-relaxed">Secure rent collection service</p>
                      <div className="text-4xl font-bold bg-gradient-to-r from-pink-600 to-pink-800 bg-clip-text text-transparent mb-3">
                        5%<span className="text-xl font-normal text-slate-600"> of rent</span>
                      </div>
                      <p className="text-slate-600 text-sm leading-relaxed">
                        Hassle-free rent collection with secure payment processing, multiple payment methods, 
                        financial reporting, and automated reconciliation.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="absolute -inset-1 bg-gradient-to-br from-purple-400 via-pink-400 to-red-400 rounded-3xl blur opacity-20"></div>
              <div className="relative bg-gradient-to-br from-purple-50 via-pink-50 to-red-50 rounded-3xl p-10 border border-purple-200 shadow-2xl">
                <h3 className="text-2xl font-bold mb-8 bg-gradient-to-r from-purple-800 to-pink-800 bg-clip-text text-transparent">
                  Additional Revenue Streams
                </h3>
                <div className="space-y-4">
                  <div className="group flex justify-between items-center p-6 bg-white/80 backdrop-blur-sm rounded-2xl border border-purple-100 hover:bg-white transition-all duration-300 hover:shadow-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-purple-400 to-purple-500 rounded-xl flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                      <span className="font-semibold text-slate-800">Tenant Referencing</span>
                    </div>
                    <span className="text-xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">£15-25</span>
                  </div>
                  
                  <div className="group flex justify-between items-center p-6 bg-white/80 backdrop-blur-sm rounded-2xl border border-purple-100 hover:bg-white transition-all duration-300 hover:shadow-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-pink-400 to-pink-500 rounded-xl flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                      <span className="font-semibold text-slate-800">Deposit Protection</span>
                    </div>
                    <span className="text-xl font-bold bg-gradient-to-r from-pink-600 to-red-600 bg-clip-text text-transparent">£20-30</span>
                  </div>
                  
                  <div className="group flex justify-between items-center p-6 bg-white/80 backdrop-blur-sm rounded-2xl border border-purple-100 hover:bg-white transition-all duration-300 hover:shadow-lg">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-gradient-to-r from-red-400 to-red-500 rounded-xl flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                      <span className="font-semibold text-slate-800">Marketplace Commission</span>
                    </div>
                    <span className="text-xl font-bold bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">10-15%</span>
                  </div>
                </div>
                
                <div className="mt-8 p-6 bg-gradient-to-r from-purple-100 to-pink-100 rounded-2xl border border-purple-200">
                  <div className="text-center">
                    <div className="text-sm font-semibold text-purple-700 mb-2">Revenue Mix</div>
                    <div className="text-3xl font-bold bg-gradient-to-r from-purple-800 to-pink-800 bg-clip-text text-transparent mb-2">25% | 75%</div>
                    <div className="text-sm text-purple-600">Subscription | Payment Processing</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Competitive Advantage Section */}
      <section className="py-32 bg-gradient-to-br from-slate-50 via-white to-slate-100 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `linear-gradient(30deg, #f1f5f9 12%, transparent 12.5%, transparent 87%, #f1f5f9 87.5%, #f1f5f9), 
                             linear-gradient(150deg, #f1f5f9 12%, transparent 12.5%, transparent 87%, #f1f5f9 87.5%, #f1f5f9), 
                             linear-gradient(30deg, #f1f5f9 12%, transparent 12.5%, transparent 87%, #f1f5f9 87.5%, #f1f5f9), 
                             linear-gradient(150deg, #f1f5f9 12%, transparent 12.5%, transparent 87%, #f1f5f9 87.5%, #f1f5f9), 
                             linear-gradient(60deg, #f1f5f977 25%, transparent 25.5%, transparent 75%, #f1f5f977 75%, #f1f5f977)`,
            backgroundSize: '80px 140px',
            backgroundPosition: '0 0, 0 0, 40px 70px, 40px 70px, 0 0'
          }}></div>
        </div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-20">
            <div className="inline-flex items-center gap-2 bg-gradient-to-r from-orange-100 to-red-100 rounded-full px-6 py-2 mb-6">
              <div className="w-2 h-2 bg-orange-600 rounded-full animate-pulse"></div>
              <span className="text-sm font-semibold text-orange-900">COMPETITIVE ADVANTAGE</span>
            </div>
            <h2 className="text-4xl lg:text-5xl xl:text-6xl font-bold mb-6 bg-gradient-to-r from-orange-600 via-red-600 to-pink-600 bg-clip-text text-transparent leading-tight">
              Competitive Advantage
            </h2>
            <p className="text-xl lg:text-2xl text-slate-600 max-w-3xl mx-auto leading-relaxed font-light">
              Why choose Property Manager Pro over traditional agents and other PropTech solutions.
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-red-400 to-red-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <div className="relative bg-white rounded-2xl shadow-xl p-8 border border-red-100 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
                <div className="text-center mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-red-400 to-red-500 rounded-2xl mb-4 shadow-lg">
                    <div className="text-2xl font-bold text-white">T</div>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Traditional Agents</h3>
                  <p className="text-lg font-semibold text-red-600 mb-4">8-15% of rent + £500-£1,500 tenant fee</p>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-red-50 rounded-xl">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                    <span className="text-slate-700 font-medium">Full-service including viewings & maintenance</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-red-50 rounded-xl">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                    <span className="text-slate-700 font-medium">Manual processes, human expertise</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                    <div className="w-6 h-6 bg-slate-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-slate-400 rounded-full"></div>
                    </div>
                    <span className="text-slate-500 font-medium">Basic or outdated systems</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                    <div className="w-6 h-6 bg-slate-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-slate-400 rounded-full"></div>
                    </div>
                    <span className="text-slate-500 font-medium">Convenience at premium price</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-green-400 to-green-600 rounded-3xl blur opacity-40 group-hover:opacity-60 transition duration-300"></div>
              <div className="relative bg-white rounded-2xl shadow-2xl p-8 border-2 border-green-200 hover:shadow-3xl transition-all duration-500 hover:-translate-y-3 transform scale-105">
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-gradient-to-r from-green-500 to-emerald-500 text-white px-6 py-2 rounded-full text-sm font-bold shadow-lg">
                    OUR PLATFORM
                  </div>
                </div>
                <div className="text-center mb-6 pt-4">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-green-400 to-emerald-500 rounded-2xl mb-4 shadow-lg">
                    <div className="text-2xl font-bold text-white">P</div>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Property Manager Pro</h3>
                  <p className="text-lg font-semibold text-green-600 mb-4">£10/month + 5% payment processing</p>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-green-50 rounded-xl">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                    <span className="text-slate-700 font-medium">Compliance dashboard, maintenance logging</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-green-50 rounded-xl">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                    <span className="text-slate-700 font-medium">Real-time AI advisor with up-to-date regulations</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-green-50 rounded-xl">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                    <span className="text-slate-700 font-medium">AI-powered compliance tools</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-green-50 rounded-xl">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                    <span className="text-slate-700 font-medium">Professional tools at 60% cost of traditional agents</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="group relative">
              <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-blue-600 rounded-3xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <div className="relative bg-white rounded-2xl shadow-xl p-8 border border-blue-100 hover:shadow-2xl transition-all duration-500 hover:-translate-y-2">
                <div className="text-center mb-6">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-blue-400 to-blue-500 rounded-2xl mb-4 shadow-lg">
                    <div className="text-2xl font-bold text-white">O</div>
                  </div>
                  <h3 className="text-2xl font-bold text-slate-900 mb-2">Other PropTech</h3>
                  <p className="text-lg font-semibold text-blue-600 mb-4">£15-25/month + additional fees</p>
                </div>
                <div className="space-y-4">
                  <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                    <span className="text-slate-700 font-medium">Limited or no management tools</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-xl">
                    <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    </div>
                    <span className="text-slate-700 font-medium">Basic compliance reminders</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                    <div className="w-6 h-6 bg-slate-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-slate-400 rounded-full"></div>
                    </div>
                    <span className="text-slate-500 font-medium">Standard property management tools</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                    <div className="w-6 h-6 bg-slate-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <div className="w-3 h-3 bg-slate-400 rounded-full"></div>
                    </div>
                    <span className="text-slate-500 font-medium">Basic tools for DIY landlords</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-32 overflow-hidden">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-blue-900 to-purple-900"></div>
        
        {/* Animated Background Elements */}
        <div className="absolute inset-0">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(ellipse_at_top,rgba(59,130,246,0.15)_0%,transparent_50%)]"></div>
          <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_bottom,rgba(147,51,234,0.15)_0%,transparent_50%)]"></div>
        </div>
        
        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-pulse animation-delay-2000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-pink-500 rounded-full mix-blend-multiply filter blur-3xl opacity-10 animate-pulse animation-delay-4000"></div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="max-w-6xl mx-auto text-center">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/20 rounded-full px-8 py-3 mb-8">
              <Sparkles className="h-6 w-6 text-yellow-300" />
              <span className="text-lg font-semibold text-white">GET STARTED TODAY</span>
              <Star className="h-6 w-6 text-yellow-300" />
            </div>
            
            {/* Main Heading */}
            <h2 className="text-5xl lg:text-6xl xl:text-7xl font-bold mb-8 leading-tight">
              <span className="block text-white mb-4">Ready to Transform Your</span>
              <span className="block bg-gradient-to-r from-yellow-300 via-orange-300 to-pink-300 bg-clip-text text-transparent">
                Property Management?
              </span>
            </h2>
            
            {/* Subtitle */}
            <p className="text-xl lg:text-2xl text-white/80 mb-16 max-w-4xl mx-auto leading-relaxed font-light">
              Join thousands of UK landlords who are already saving time and money with our professional platform.
            </p>
            
            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-8 justify-center mb-16">
              <Button size="lg" className="group text-xl px-12 py-6 bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-slate-900 font-bold shadow-2xl hover:shadow-yellow-500/30 transition-all duration-500 hover:scale-105 hover:rotate-1">
                Start Your Free Trial
                <ArrowRight className="ml-4 h-7 w-7 group-hover:translate-x-2 transition-transform" />
              </Button>
              <Button variant="outline" size="lg" className="group text-xl px-12 py-6 bg-white/10 text-white border-white/30 hover:bg-white/20 hover:border-white/50 backdrop-blur-md font-medium shadow-2xl hover:shadow-white/20 transition-all duration-500 hover:scale-105 hover:-rotate-1">
                Schedule a Demo
                <div className="ml-4 w-8 h-8 rounded-full border-3 border-white/50 flex items-center justify-center group-hover:border-white/80 transition-colors">
                  <div className="w-3 h-3 bg-white rounded-full group-hover:scale-125 transition-transform"></div>
                </div>
              </Button>
            </div>
            
            {/* Trust Elements */}
            <div className="bg-white/5 backdrop-blur-md rounded-3xl p-8 border border-white/10 max-w-2xl mx-auto">
              <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-white/80">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                  <span className="font-medium">No credit card required</span>
                </div>
                <div className="hidden sm:block w-px h-6 bg-white/20"></div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-blue-400 rounded-full animate-pulse"></div>
                  <span className="font-medium">14-day free trial</span>
                </div>
                <div className="hidden sm:block w-px h-6 bg-white/20"></div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-pulse"></div>
                  <span className="font-medium">Cancel anytime</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white py-16 overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute inset-0" style={{
            backgroundImage: `radial-gradient(circle at 25% 25%, rgba(255,255,255,0.1) 0%, transparent 50%), 
                             radial-gradient(circle at 75% 75%, rgba(255,255,255,0.1) 0%, transparent 50%)`,
            backgroundSize: '100px 100px'
          }}></div>
        </div>
        
        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-purple-400 rounded-full blur opacity-30"></div>
                <div className="relative bg-gradient-to-r from-blue-500 to-purple-500 p-0.5 rounded-full">
                  <div className="bg-slate-800 rounded-full p-3">
                    <Building2 className="h-10 w-10 text-transparent bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text" />
                  </div>
                </div>
              </div>
              <h3 className="text-2xl font-bold bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
                Property Manager Pro
              </h3>
            </div>
            <p className="text-slate-300 text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
              Professional property management tools at a fraction of traditional costs.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-8">
              <div className="flex items-center gap-2 text-slate-400">
                <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                <span>Secure & Compliant</span>
              </div>
              <div className="hidden sm:block w-px h-4 bg-slate-600"></div>
              <div className="flex items-center gap-2 text-slate-400">
                <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                <span>AI-Powered</span>
              </div>
              <div className="hidden sm:block w-px h-4 bg-slate-600"></div>
              <div className="flex items-center gap-2 text-slate-400">
                <div className="w-2 h-2 bg-purple-400 rounded-full"></div>
                <span>Cost Effective</span>
              </div>
            </div>
            <div className="border-t border-slate-700 pt-8">
              <p className="text-slate-400 text-sm">
                &copy; 2024 Property Manager Pro. All rights reserved. | 
                <span className="text-slate-500"> Built with passion for property management excellence</span>
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}