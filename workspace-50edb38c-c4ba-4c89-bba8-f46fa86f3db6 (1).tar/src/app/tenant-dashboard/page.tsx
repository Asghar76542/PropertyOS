'use client'

import Link from 'next/link'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { 
  Home, 
  DollarSign, 
  Wrench, 
  FileText, 
  MessageSquare, 
  Bell,
  Calendar,
  CheckCircle,
  Clock,
  AlertTriangle,
  Users,
  CreditCard,
  Loader2,
  Building2,
  Settings
} from "lucide-react"

interface TenantData {
  personalInfo: {
    name: string
    email: string
    phone: string
    moveInDate: string
    leaseEnd: string
    propertyAddress: string
    propertyCity: string
    landlordName: string
    landlordEmail: string
    landlordPhone: string
  }
  financials: {
    monthlyRent: number
    securityDeposit: number
    balanceDue: number
    lastPaymentDate: string
    nextPaymentDue: string
    paymentHistory: Array<{
      id: string
      amount: number
      date: string
      status: string
      method: string
    }>
  }
  maintenance: {
    openRequests: number
    inProgress: number
    completed: number
    recentRequests: Array<{
      id: string
      title: string
      status: string
      priority: string
      submittedDate: string
      estimatedCompletion: string
    }>
  }
  documents: {
    leaseAgreement: {
      available: boolean
      lastUpdated: string
    }
    importantDocuments: Array<{
      id: string
      name: string
      type: string
      uploadDate: string
      size: string
    }>
  }
  communications: {
    unreadMessages: number
    recentMessages: Array<{
      id: string
      from: string
      subject: string
      message: string
      date: string
      unread: boolean
    }>
  }
}

export default function TenantDashboard() {
  const [activeTab, setActiveTab] = useState("overview")
  const [tenantData, setTenantData] = useState<TenantData | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchTenantData = async () => {
    setLoading(true)
    setError(null)
    try {
      const response = await fetch('/api/tenant/dashboard')
      if (!response.ok) {
        throw new Error('Failed to fetch tenant data')
      }
      const data = await response.json()
      setTenantData(data)
    } catch (err) {
      console.error('Error fetching tenant data:', err)
      // Fallback to mock data if API fails
      const mockData: TenantData = {
        personalInfo: {
          name: "Sarah Johnson",
          email: "sarah.johnson@email.com",
          phone: "+44 7700 900123",
          moveInDate: "2023-06-01",
          leaseEnd: "2024-05-31",
          propertyAddress: "123 Main Street, Apt 4B",
          propertyCity: "London",
          landlordName: "John Smith",
          landlordEmail: "john.smith@propertymanager.com",
          landlordPhone: "+44 7700 900456"
        },
        financials: {
          monthlyRent: 1200,
          securityDeposit: 1200,
          balanceDue: 0,
          lastPaymentDate: "2024-01-01",
          nextPaymentDue: "2024-02-01",
          paymentHistory: [
            {
              id: "1",
              amount: 1200,
              date: "2024-01-01",
              status: "completed",
              method: "bank_transfer"
            },
            {
              id: "2",
              amount: 1200,
              date: "2023-12-01",
              status: "completed",
              method: "bank_transfer"
            },
            {
              id: "3",
              amount: 1200,
              date: "2023-11-01",
              status: "completed",
              method: "direct_debit"
            }
          ]
        },
        maintenance: {
          openRequests: 1,
          inProgress: 0,
          completed: 2,
          recentRequests: [
            {
              id: "1",
              title: "Kitchen faucet leaking",
              status: "open",
              priority: "medium",
              submittedDate: "2024-01-15",
              estimatedCompletion: "2024-01-20"
            },
            {
              id: "2",
              title: "Bedroom light bulb replacement",
              status: "completed",
              priority: "low",
              submittedDate: "2024-01-10",
              estimatedCompletion: "2024-01-12"
            }
          ]
        },
        documents: {
          leaseAgreement: {
            available: true,
            lastUpdated: "2023-06-01"
          },
          importantDocuments: [
            {
              id: "1",
              name: "Lease Agreement 2023-2024",
              type: "Lease",
              uploadDate: "2023-06-01",
              size: "2.4 MB"
            },
            {
              id: "2",
              name: "Move-in Inspection Report",
              type: "Inspection",
              uploadDate: "2023-06-01",
              size: "1.8 MB"
            },
            {
              id: "3",
              name: "Building Rules & Regulations",
              type: "Rules",
              uploadDate: "2023-06-01",
              size: "856 KB"
            }
          ]
        },
        communications: {
          unreadMessages: 2,
          recentMessages: [
            {
              id: "1",
              from: "John Smith (Landlord)",
              subject: "Lease Renewal Notice",
              message: "Your lease is up for renewal next month. Please let me know if you'd like to continue.",
              date: "2024-01-16",
              unread: true
            },
            {
              id: "2",
              from: "Property Manager Pro",
              subject: "Rent Payment Reminder",
              message: "Your February rent payment is due on February 1st.",
              date: "2024-01-25",
              unread: true
            },
            {
              id: "3",
              from: "Maintenance Team",
              subject: "Maintenance Request Update",
              message: "Your kitchen faucet repair is scheduled for January 20th.",
              date: "2024-01-18",
              unread: false
            }
          ]
        }
      }
      setTenantData(mockData)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchTenantData()
  }, [])

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">Loading tenant dashboard...</p>
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center max-w-md">
          <AlertTriangle className="h-12 w-12 text-red-500 mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-red-700 mb-2">Dashboard Error</h2>
          <p className="text-red-600 mb-4">{error}</p>
          <Button onClick={fetchTenantData} className="w-full">
            Retry Loading Data
          </Button>
        </div>
      </div>
    )
  }

  if (!tenantData) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center max-w-md">
          <AlertTriangle className="h-12 w-12 text-yellow-500 mx-auto mb-4" />
          <h2 className="text-lg font-semibold text-yellow-700 mb-2">No Data Available</h2>
          <p className="text-yellow-600 mb-4">Tenant data could not be loaded</p>
          <Button onClick={fetchTenantData} className="w-full">
            Retry Loading Data
          </Button>
        </div>
      </div>
    )
  }

  // Format currency
  const formatCurrency = (amount: number) => `£${amount.toLocaleString()}`

  // Format date
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    })
  }

  // Get status badge variant
  const getStatusBadge = (status: string) => {
    switch (status.toLowerCase()) {
      case 'completed':
        return <Badge className="bg-green-100 text-green-800">Completed</Badge>
      case 'in_progress':
        return <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>
      case 'open':
        return <Badge className="bg-orange-100 text-orange-800">Open</Badge>
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>
    }
  }

  // Get priority badge variant
  const getPriorityBadge = (priority: string) => {
    switch (priority.toLowerCase()) {
      case 'high':
        return <Badge className="bg-red-100 text-red-800">High</Badge>
      case 'medium':
        return <Badge className="bg-yellow-100 text-yellow-800">Medium</Badge>
      case 'low':
        return <Badge className="bg-green-100 text-green-800">Low</Badge>
      default:
        return <Badge className="bg-gray-100 text-gray-800">{priority}</Badge>
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Header */}
      <header className="border-b bg-gradient-to-r from-green-600 via-teal-600 to-blue-600 text-white shadow-lg sticky top-0 z-40">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="relative">
                <div className="absolute -inset-1 bg-gradient-to-r from-green-400 to-teal-400 rounded-full blur opacity-30"></div>
                <div className="relative w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                  <Home className="h-6 w-6 text-white" />
                </div>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Tenant Portal</h1>
                <p className="text-sm text-white/80">Welcome back, {tenantData.personalInfo.name}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/">
                <Button variant="outline" size="sm" className="bg-white/10 text-white border-white/30 hover:bg-white/20 backdrop-blur-sm">
                  <Building2 className="h-4 w-4 mr-2" />
                  Main Site
                </Button>
              </Link>
              <Button variant="outline" size="sm" className="bg-white/10 text-white border-white/30 hover:bg-white/20 backdrop-blur-sm relative">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
                {tenantData.communications.unreadMessages > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                    {tenantData.communications.unreadMessages}
                  </span>
                )}
              </Button>
              <Button variant="outline" size="sm" className="bg-white/10 text-white border-white/30 hover:bg-white/20 backdrop-blur-sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-5 bg-white/50 backdrop-blur-sm p-1 rounded-xl shadow-sm">
            <TabsTrigger value="overview" className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg">Overview</TabsTrigger>
            <TabsTrigger value="payments" className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg">Payments</TabsTrigger>
            <TabsTrigger value="maintenance" className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg">Maintenance</TabsTrigger>
            <TabsTrigger value="documents" className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg">Documents</TabsTrigger>
            <TabsTrigger value="messages" className="data-[state=active]:bg-white data-[state=active]:shadow-sm rounded-lg">Messages</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-8">
            {/* Key Metrics */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="group relative overflow-hidden">
                <div className="absolute -inset-1 bg-gradient-to-r from-green-400 to-green-600 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
                <Card className="relative bg-white rounded-2xl shadow-lg border-0">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-green-700">Monthly Rent</CardTitle>
                    <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center shadow-lg">
                      <DollarSign className="h-5 w-5 text-white" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-green-600">{formatCurrency(tenantData.financials.monthlyRent)}</div>
                    <p className="text-xs text-green-600">
                      Next due: {formatDate(tenantData.financials.nextPaymentDue)}
                    </p>
                  </CardContent>
                </Card>
              </Card>

              <Card className="group relative overflow-hidden">
                <div className="absolute -inset-1 bg-gradient-to-r from-blue-400 to-blue-600 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
                <Card className="relative bg-white rounded-2xl shadow-lg border-0">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-blue-700">Security Deposit</CardTitle>
                    <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center shadow-lg">
                      <CreditCard className="h-5 w-5 text-white" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-blue-600">{formatCurrency(tenantData.financials.securityDeposit)}</div>
                    <p className="text-xs text-blue-600">Held securely</p>
                  </CardContent>
                </Card>
              </Card>

              <Card className="group relative overflow-hidden">
                <div className="absolute -inset-1 bg-gradient-to-r from-orange-400 to-orange-600 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
                <Card className="relative bg-white rounded-2xl shadow-lg border-0">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-orange-700">Open Requests</CardTitle>
                    <div className="w-10 h-10 bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl flex items-center justify-center shadow-lg">
                      <Wrench className="h-5 w-5 text-white" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-orange-600">{tenantData.maintenance.openRequests}</div>
                    <p className="text-xs text-orange-600">
                      {tenantData.maintenance.inProgress} in progress
                    </p>
                  </CardContent>
                </Card>
              </Card>

              <Card className="group relative overflow-hidden">
                <div className="absolute -inset-1 bg-gradient-to-r from-purple-400 to-purple-600 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
                <Card className="relative bg-white rounded-2xl shadow-lg border-0">
                  <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-purple-700">Unread Messages</CardTitle>
                    <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
                      <MessageSquare className="h-5 w-5 text-white" />
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="text-3xl font-bold text-purple-600">{tenantData.communications.unreadMessages}</div>
                    <p className="text-xs text-purple-600">New messages</p>
                  </CardContent>
                </Card>
              </Card>
            </div>

            {/* Property Info Card */}
            <Card className="group relative overflow-hidden">
              <div className="absolute -inset-1 bg-gradient-to-r from-green-400 to-blue-400 rounded-2xl blur opacity-25 group-hover:opacity-40 transition duration-300"></div>
              <Card className="relative bg-white rounded-2xl shadow-lg border-0">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 text-green-700">
                    <Home className="h-5 w-5" />
                    Property Information
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <p className="font-medium text-gray-800 mb-2">Address</p>
                        <p className="text-sm text-gray-600">{tenantData.personalInfo.propertyAddress}</p>
                        <p className="text-sm text-gray-600">{tenantData.personalInfo.propertyCity}</p>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800 mb-2">Lease Period</p>
                        <p className="text-sm text-gray-600">{formatDate(tenantData.personalInfo.moveInDate)} - {formatDate(tenantData.personalInfo.leaseEnd)}</p>
                      </div>
                    </div>
                    <div className="space-y-4">
                      <div>
                        <p className="font-medium text-gray-800 mb-2">Landlord</p>
                        <p className="text-sm text-gray-600">{tenantData.personalInfo.landlordName}</p>
                        <p className="text-sm text-gray-600">{tenantData.personalInfo.landlordEmail}</p>
                        <p className="text-sm text-gray-600">{tenantData.personalInfo.landlordPhone}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Card>
          </TabsContent>

          {/* Other tabs would go here - simplified for now */}
          <TabsContent value="payments" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Payment History</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Payment tracking functionality would be implemented here.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="maintenance" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Maintenance Requests</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Maintenance request functionality would be implemented here.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="documents" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Documents</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Document management functionality would be implemented here.</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="messages" className="space-y-8">
            <Card>
              <CardHeader>
                <CardTitle>Messages</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">Messaging functionality would be implemented here.</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}