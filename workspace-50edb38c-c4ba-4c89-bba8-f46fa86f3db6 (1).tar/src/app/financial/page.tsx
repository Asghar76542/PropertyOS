'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { 
  Building2, 
  DollarSign, 
  TrendingUp, 
  TrendingDown,
  Plus, 
  Search,
  Home,
  Bell,
  Settings,
  Calendar,
  Clock,
  CreditCard,
  AlertTriangle,
  Filter,
  MoreHorizontal,
  Eye,
  Edit,
  Download,
  FileText,
  BarChart3,
  PieChart,
  Target,
  Receipt,
  Users
} from "lucide-react"

export default function Financial() {
  const [activeTab, setActiveTab] = useState("overview")
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedProperty, setSelectedProperty] = useState("all")
  const [selectedStatus, setSelectedStatus] = useState("all")
  const [selectedMonth, setSelectedMonth] = useState("current")

  // Mock financial data
  const properties = [
    {
      id: 1,
      address: "123 Main Street, London",
      monthlyRent: 1200,
      tenant: "John Smith",
      status: "occupied",
      lastPayment: "2024-01-15",
      nextPayment: "2024-02-15",
      paymentStatus: "paid",
      yearToDate: 14400
    },
    {
      id: 2,
      address: "456 Park Avenue, Manchester",
      monthlyRent: 1500,
      tenant: "Mike Wilson",
      status: "occupied",
      lastPayment: "2024-01-10",
      nextPayment: "2024-02-10",
      paymentStatus: "paid",
      yearToDate: 18000
    },
    {
      id: 3,
      address: "789 High Street, Birmingham",
      monthlyRent: 950,
      tenant: "Sarah Johnson",
      status: "occupied",
      lastPayment: null,
      nextPayment: "2024-02-01",
      paymentStatus: "overdue",
      yearToDate: 10450
    }
  ]

  const rentPayments = [
    {
      id: 1,
      property: "123 Main Street, London",
      tenant: "John Smith",
      amount: 1200,
      date: "2024-01-15",
      status: "completed",
      method: "bank_transfer",
      reference: "REN-2024-001",
      fees: 60
    },
    {
      id: 2,
      property: "456 Park Avenue, Manchester",
      tenant: "Mike Wilson",
      amount: 1500,
      date: "2024-01-10",
      status: "completed",
      method: "bank_transfer",
      reference: "REN-2024-002",
      fees: 75
    },
    {
      id: 3,
      property: "789 High Street, Birmingham",
      tenant: "Sarah Johnson",
      amount: 950,
      date: "2024-01-01",
      status: "failed",
      method: "direct_debit",
      reference: "REN-2024-003",
      fees: 0
    },
    {
      id: 4,
      property: "123 Main Street, London",
      tenant: "John Smith",
      amount: 1200,
      date: "2023-12-15",
      status: "completed",
      method: "bank_transfer",
      reference: "REN-2023-012",
      fees: 60
    },
    {
      id: 5,
      property: "456 Park Avenue, Manchester",
      tenant: "Mike Wilson",
      amount: 1500,
      date: "2023-12-10",
      status: "completed",
      method: "bank_transfer",
      reference: "REN-2023-011",
      fees: 75
    }
  ]

  const expenses = [
    {
      id: 1,
      category: "maintenance",
      description: "Plumbing repair - kitchen tap",
      amount: 150,
      date: "2024-01-16",
      property: "123 Main Street, London",
      status: "completed",
      receipt: "receipt-001.pdf"
    },
    {
      id: 2,
      category: "utilities",
      description: "Council tax Q1 2024",
      amount: 450,
      date: "2024-01-15",
      property: "All Properties",
      status: "paid",
      receipt: "council-tax-001.pdf"
    },
    {
      id: 3,
      category: "insurance",
      description: "Property insurance annual premium",
      amount: 1200,
      date: "2024-01-10",
      property: "All Properties",
      status: "paid",
      receipt: "insurance-001.pdf"
    },
    {
      id: 4,
      category: "maintenance",
      description: "Heating system repair",
      amount: 300,
      date: "2024-01-12",
      property: "789 High Street, Birmingham",
      status: "pending",
      receipt: null
    },
    {
      id: 5,
      category: "services",
      description: "Cleaning service",
      amount: 100,
      date: "2024-01-08",
      property: "456 Park Avenue, Manchester",
      status: "completed",
      receipt: "cleaning-001.pdf"
    }
  ]

  const financialSummary = {
    totalProperties: properties.length,
    occupiedProperties: properties.filter(p => p.status === "occupied").length,
    monthlyRent: properties.reduce((sum, p) => sum + p.monthlyRent, 0),
    collectedRent: properties.filter(p => p.paymentStatus === "paid").reduce((sum, p) => sum + p.monthlyRent, 0),
    pendingRent: properties.filter(p => p.paymentStatus === "pending").reduce((sum, p) => sum + p.monthlyRent, 0),
    overdueRent: properties.filter(p => p.paymentStatus === "overdue").reduce((sum, p) => sum + p.monthlyRent, 0),
    totalExpenses: expenses.reduce((sum, e) => sum + e.amount, 0),
    netIncome: properties.filter(p => p.paymentStatus === "paid").reduce((sum, p) => sum + p.monthlyRent, 0) - expenses.reduce((sum, e) => sum + e.amount, 0),
    occupancyRate: (properties.filter(p => p.status === "occupied").length / properties.length) * 100,
    collectionRate: (properties.filter(p => p.paymentStatus === "paid").length / properties.length) * 100,
    yearToDateRevenue: properties.reduce((sum, p) => sum + p.yearToDate, 0),
    averageRent: properties.reduce((sum, p) => sum + p.monthlyRent, 0) / properties.length
  }

  const monthlyData = [
    { month: "Jan", rent: 3650, expenses: 2200, net: 1450 },
    { month: "Feb", rent: 3650, expenses: 1800, net: 1850 },
    { month: "Mar", rent: 3650, expenses: 2000, net: 1650 },
    { month: "Apr", rent: 3650, expenses: 1900, net: 1750 },
    { month: "May", rent: 3650, expenses: 2100, net: 1550 },
    { month: "Jun", rent: 3650, expenses: 1700, net: 1950 }
  ]

  const filteredPayments = rentPayments.filter(payment => {
    const matchesSearch = payment.property.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         payment.tenant.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         payment.reference.toLowerCase().includes(searchQuery.toLowerCase())
    const matchesProperty = selectedProperty === "all" || payment.property === selectedProperty
    const matchesStatus = selectedStatus === "all" || payment.status === selectedStatus
    
    return matchesSearch && matchesProperty && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "default"
      case "paid": return "default"
      case "pending": return "secondary"
      case "failed": return "destructive"
      case "overdue": return "destructive"
      default: return "secondary"
    }
  }

  const getPaymentMethodIcon = (method: string) => {
    switch (method) {
      case "bank_transfer": return <CreditCard className="h-4 w-4" />
      case "direct_debit": return <DollarSign className="h-4 w-4" />
      default: return <CreditCard className="h-4 w-4" />
    }
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Building2 className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">Property Manager Pro</h1>
                <p className="text-sm text-muted-foreground">Financial Dashboard</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/">
                <Button variant="outline" size="sm">
                  <Home className="h-4 w-4 mr-2" />
                  Home
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button variant="outline" size="sm">Dashboard</Button>
              </Link>
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </Button>
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-2xl font-bold">Financial Overview</h2>
            <p className="text-muted-foreground">Track rent payments, expenses, and financial performance</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Record Payment
            </Button>
          </div>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Monthly Rent</p>
                  <p className="text-2xl font-bold">£{financialSummary.monthlyRent}</p>
                  <p className="text-xs text-muted-foreground">
                    £{financialSummary.collectedRent} collected
                  </p>
                </div>
                <DollarSign className="h-8 w-8 text-green-500" />
              </div>
              <Progress value={financialSummary.collectionRate} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Net Income</p>
                  <p className="text-2xl font-bold text-green-600">£{financialSummary.netIncome}</p>
                  <p className="text-xs text-muted-foreground">
                    After £{financialSummary.totalExpenses} expenses
                  </p>
                </div>
                <TrendingUp className="h-8 w-8 text-green-500" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Occupancy Rate</p>
                  <p className="text-2xl font-bold">{financialSummary.occupancyRate.toFixed(0)}%</p>
                  <p className="text-xs text-muted-foreground">
                    {financialSummary.occupiedProperties}/{financialSummary.totalProperties} occupied
                  </p>
                </div>
                <BarChart3 className="h-8 w-8 text-blue-500" />
              </div>
              <Progress value={financialSummary.occupancyRate} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Overdue Rent</p>
                  <p className="text-2xl font-bold text-red-600">£{financialSummary.overdueRent}</p>
                  <p className="text-xs text-muted-foreground">
                    Requires attention
                  </p>
                </div>
                <AlertTriangle className="h-8 w-8 text-red-500" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="rent">Rent Tracking</TabsTrigger>
            <TabsTrigger value="expenses">Expenses</TabsTrigger>
            <TabsTrigger value="reports">Reports</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Property Performance</CardTitle>
                  <CardDescription>Monthly rent collection by property</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {properties.map((property) => (
                      <div key={property.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-medium">{property.address}</h4>
                          <p className="text-sm text-muted-foreground">{property.tenant}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">£{property.monthlyRent}</p>
                          <Badge variant={getStatusColor(property.paymentStatus)} className="text-xs">
                            {property.paymentStatus}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Recent Transactions</CardTitle>
                  <CardDescription>Latest rent payments and expenses</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {rentPayments.slice(0, 5).map((payment) => (
                      <div key={payment.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex items-center gap-3">
                          {getPaymentMethodIcon(payment.method)}
                          <div>
                            <p className="font-medium">{payment.tenant}</p>
                            <p className="text-sm text-muted-foreground">{payment.property}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">£{payment.amount}</p>
                          <p className="text-xs text-muted-foreground">{payment.date}</p>
                        </div>
                      </div>
                    ))}
                    {expenses.slice(0, 3).map((expense) => (
                      <div key={expense.id} className="flex items-center justify-between p-3 border rounded-lg bg-red-50">
                        <div className="flex items-center gap-3">
                          <Receipt className="h-4 w-4 text-red-600" />
                          <div>
                            <p className="font-medium">{expense.description}</p>
                            <p className="text-sm text-muted-foreground">{expense.property}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-red-600">-£{expense.amount}</p>
                          <p className="text-xs text-muted-foreground">{expense.date}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="rent" className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4 mb-6">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search payments..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <Select value={selectedProperty} onValueChange={setSelectedProperty}>
                <SelectTrigger className="w-full md:w-64">
                  <SelectValue placeholder="Property" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Properties</SelectItem>
                  {properties.map((property) => (
                    <SelectItem key={property.id} value={property.address}>
                      {property.address}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select value={selectedStatus} onValueChange={setSelectedStatus}>
                <SelectTrigger className="w-full md:w-40">
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="failed">Failed</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="grid gap-4">
              {filteredPayments.map((payment) => (
                <Card key={payment.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div className={`p-3 rounded-lg ${
                          payment.status === 'completed' ? 'bg-green-100' : 'bg-red-100'
                        }`}>
                          {getPaymentMethodIcon(payment.method)}
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold">{payment.tenant}</h3>
                            <Badge variant={getStatusColor(payment.status)}>
                              {payment.status}
                            </Badge>
                          </div>
                          <p className="text-muted-foreground mb-2">{payment.property}</p>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Amount:</span>
                              <p className="font-medium">£{payment.amount}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Date:</span>
                              <p className="font-medium">{payment.date}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Reference:</span>
                              <p className="font-medium">{payment.reference}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4 mr-1" />
                          Receipt
                        </Button>
                        <Button variant="outline" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="expenses" className="space-y-6">
            <div className="grid gap-4">
              {expenses.map((expense) => (
                <Card key={expense.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-4 flex-1">
                        <div className="p-3 bg-red-100 rounded-lg">
                          <Receipt className="h-6 w-6 text-red-600" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold">{expense.description}</h3>
                            <Badge variant={getStatusColor(expense.status)}>
                              {expense.status}
                            </Badge>
                            <Badge variant="outline">{expense.category}</Badge>
                          </div>
                          <p className="text-muted-foreground mb-2">{expense.property}</p>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                            <div>
                              <span className="text-muted-foreground">Amount:</span>
                              <p className="font-medium text-red-600">£{expense.amount}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Date:</span>
                              <p className="font-medium">{expense.date}</p>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Receipt:</span>
                              <p className="font-medium">{expense.receipt || 'No receipt'}</p>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                        {expense.receipt && (
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-1" />
                            Receipt
                          </Button>
                        )}
                        <Button variant="outline" size="sm">
                          <Edit className="h-4 w-4 mr-1" />
                          Edit
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="reports" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardHeader>
                  <FileText className="h-8 w-8 text-blue-600 mb-2" />
                  <CardTitle>Income Statement</CardTitle>
                  <CardDescription>Monthly income and expenses report</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Comprehensive view of rental income and operating expenses
                  </p>
                  <Button variant="outline" className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardHeader>
                  <BarChart3 className="h-8 w-8 text-green-600 mb-2" />
                  <CardTitle>Rent Roll Report</CardTitle>
                  <CardDescription>Detailed rent collection analysis</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Track rent payments, arrears, and collection rates
                  </p>
                  <Button variant="outline" className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardHeader>
                  <PieChart className="h-8 w-8 text-purple-600 mb-2" />
                  <CardTitle>Expense Breakdown</CardTitle>
                  <CardDescription>Categorized expense analysis</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    View expenses by category and property
                  </p>
                  <Button variant="outline" className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardHeader>
                  <Target className="h-8 w-8 text-orange-600 mb-2" />
                  <CardTitle>Performance Metrics</CardTitle>
                  <CardDescription>Key performance indicators</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Occupancy rates, yield analysis, and ROI metrics
                  </p>
                  <Button variant="outline" className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardHeader>
                  <Users className="h-8 w-8 text-red-600 mb-2" />
                  <CardTitle>Tenant Ledger</CardTitle>
                  <CardDescription>Individual tenant payment history</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Detailed payment history for each tenant
                  </p>
                  <Button variant="outline" className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-md transition-shadow cursor-pointer">
                <CardHeader>
                  <Calendar className="h-8 w-8 text-indigo-600 mb-2" />
                  <CardTitle>Annual Summary</CardTitle>
                  <CardDescription>Year-end financial summary</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    Complete annual financial overview and tax preparation
                  </p>
                  <Button variant="outline" className="w-full">
                    <Download className="h-4 w-4 mr-2" />
                    Generate Report
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Monthly Performance</CardTitle>
                  <CardDescription>Income vs expenses over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {monthlyData.map((data, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{data.month}</span>
                          <span>Net: £{data.net}</span>
                        </div>
                        <div className="flex gap-2">
                          <div className="flex-1">
                            <div className="text-xs text-muted-foreground mb-1">Rent: £{data.rent}</div>
                            <Progress value={100} className="h-2" />
                          </div>
                          <div className="flex-1">
                            <div className="text-xs text-muted-foreground mb-1">Expenses: £{data.expenses}</div>
                            <Progress value={(data.expenses / data.rent) * 100} className="h-2" />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Expense Categories</CardTitle>
                  <CardDescription>Breakdown of expenses by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Maintenance</span>
                      <div className="flex items-center gap-2">
                        <Progress value={35} className="w-20" />
                        <span className="text-sm">35%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Utilities</span>
                      <div className="flex items-center gap-2">
                        <Progress value={25} className="w-20" />
                        <span className="text-sm">25%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Insurance</span>
                      <div className="flex items-center gap-2">
                        <Progress value={20} className="w-20" />
                        <span className="text-sm">20%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Services</span>
                      <div className="flex items-center gap-2">
                        <Progress value={20} className="w-20" />
                        <span className="text-sm">20%</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}