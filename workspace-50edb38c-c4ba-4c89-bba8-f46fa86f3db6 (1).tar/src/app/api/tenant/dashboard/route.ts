import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    // Get the first tenant as an example
    // In a real application, this would be authenticated and get the tenant's actual data
    const tenant = await db.user.findFirst({
      where: { role: 'TENANT' }
    })

    if (!tenant) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 })
    }

    // Get tenant's tenancy information
    const tenancy = await db.tenancy.findFirst({
      where: { tenantId: tenant.id },
      include: {
        property: {
          include: {
            landlord: true
          }
        }
      }
    })

    if (!tenancy) {
      return NextResponse.json({ error: 'Tenancy not found' }, { status: 404 })
    }

    // Get payment history
    const payments = await db.payment.findMany({
      where: { tenantId: tenant.id },
      orderBy: { createdAt: 'desc' },
      take: 10
    })

    // Get maintenance requests
    const maintenanceRequests = await db.maintenanceRequest.findMany({
      where: { tenantId: tenant.id },
      orderBy: { createdAt: 'desc' },
      take: 10
    })

    // Get documents accessible to tenant
    const documents = await db.document.findMany({
      where: { 
        OR: [
          { propertyId: tenancy.propertyId, isPublic: true },
          { tenancyId: tenancy.id }
        ]
      },
      orderBy: { createdAt: 'desc' },
      take: 10
    })

    // Calculate financial summary
    const totalPaid = payments
      .filter(p => p.status === 'COMPLETED')
      .reduce((sum, payment) => sum + payment.amount, 0)

    const balanceDue = Math.max(0, tenancy.monthlyRent - totalPaid)

    // Get maintenance stats
    const maintenanceStats = {
      open: maintenanceRequests.filter(r => r.status === 'OPEN').length,
      inProgress: maintenanceRequests.filter(r => r.status === 'IN_PROGRESS').length,
      completed: maintenanceRequests.filter(r => r.status === 'COMPLETED').length
    }

    // Mock communications data (in real app, this would come from a messages table)
    const communications = {
      unreadMessages: 2,
      recentMessages: [
        {
          id: '1',
          from: `${tenancy.property.landlord.name} (Landlord)`,
          subject: 'Lease Renewal Notice',
          message: 'Your lease is up for renewal next month. Please let me know if you\'d like to continue.',
          date: new Date().toISOString(),
          unread: true
        },
        {
          id: '2',
          from: 'Property Manager Pro',
          subject: 'Rent Payment Reminder',
          message: 'Your rent payment is due soon.',
          date: new Date().toISOString(),
          unread: true
        }
      ]
    }

    const tenantData = {
      personalInfo: {
        name: tenant.name,
        email: tenant.email,
        phone: tenant.phone || '+44 7700 900123',
        moveInDate: tenancy.startDate.toISOString(),
        leaseEnd: tenancy.endDate.toISOString(),
        propertyAddress: tenancy.property.address,
        propertyCity: tenancy.property.city,
        landlordName: tenancy.property.landlord.name,
        landlordEmail: tenancy.property.landlord.email,
        landlordPhone: tenancy.property.landlord.phone || '+44 7700 900456'
      },
      financials: {
        monthlyRent: tenancy.monthlyRent,
        securityDeposit: tenancy.securityDeposit,
        balanceDue,
        lastPaymentDate: payments.length > 0 ? payments[0].createdAt.toISOString() : new Date().toISOString(),
        nextPaymentDue: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(), // 30 days from now
        paymentHistory: payments.map(payment => ({
          id: payment.id,
          amount: payment.amount,
          date: payment.createdAt.toISOString(),
          status: payment.status.toLowerCase(),
          method: payment.method?.toLowerCase().replace(' ', '_') || 'bank_transfer'
        }))
      },
      maintenance: {
        openRequests: maintenanceStats.open,
        inProgress: maintenanceStats.inProgress,
        completed: maintenanceStats.completed,
        recentRequests: maintenanceRequests.map(request => ({
          id: request.id,
          title: request.title,
          status: request.status.toLowerCase(),
          priority: request.priority.toLowerCase(),
          submittedDate: request.createdAt.toISOString(),
          estimatedCompletion: request.estimatedCompletion?.toISOString() || new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString()
        }))
      },
      documents: {
        leaseAgreement: {
          available: true,
          lastUpdated: tenancy.startDate.toISOString()
        },
        importantDocuments: documents.map(doc => ({
          id: doc.id,
          name: doc.name,
          type: doc.type,
          uploadDate: doc.createdAt.toISOString(),
          size: `${Math.round(Math.random() * 3000) + 100} KB` // Mock size
        }))
      },
      communications
    }

    return NextResponse.json(tenantData)
  } catch (error) {
    console.error('Error fetching tenant dashboard data:', error)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}