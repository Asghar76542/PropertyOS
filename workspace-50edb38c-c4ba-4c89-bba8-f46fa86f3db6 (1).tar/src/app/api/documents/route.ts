import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { z } from 'zod'

// Schema for document validation
const documentSchema = z.object({
  filename: z.string().min(1, 'Filename is required'),
  originalName: z.string().min(1, 'Original name is required'),
  filePath: z.string().min(1, 'File path is required'),
  fileSize: z.number().int().positive('File size must be positive'),
  mimeType: z.string().min(1, 'MIME type is required'),
  documentType: z.enum(['LEASE_AGREEMENT', 'GAS_SAFETY_CERTIFICATE', 'EPC_CERTIFICATE', 'ELECTRICAL_SAFETY_CERTIFICATE', 'INVENTORY_REPORT', 'DEPOSIT_PROTECTION_CERTIFICATE', 'INSURANCE_DOCUMENT', 'OTHER']),
  description: z.string().optional(),
  expiresAt: z.string().optional().transform(val => val ? new Date(val) : null),
  propertyId: z.string().min(1, 'Property ID is required'),
  uploadedBy: z.string().min(1, 'Uploader ID is required'),
  tenancyId: z.string().optional(),
})

// GET all documents
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const propertyId = searchParams.get('propertyId')
    const documentType = searchParams.get('documentType')
    const uploadedBy = searchParams.get('uploadedBy')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const offset = (page - 1) * limit

    const where: any = {}
    if (propertyId) where.propertyId = propertyId
    if (documentType) where.documentType = documentType
    if (uploadedBy) where.uploadedBy = uploadedBy

    const documents = await db.document.findMany({
      where,
      include: {
        property: {
          select: { id: true, address: true, city: true }
        },
        uploader: {
          select: { id: true, name: true, email: true }
        },
        tenancy: {
          select: { id: true, startDate: true, endDate: true }
        }
      },
      skip: offset,
      take: limit,
      orderBy: { createdAt: 'desc' }
    })

    const total = await db.document.count({ where })

    return NextResponse.json({
      documents,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Error fetching documents:', error)
    return NextResponse.json(
      { error: 'Failed to fetch documents' },
      { status: 500 }
    )
  }
}

// POST create new document
export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    
    // Validate input
    const validatedData = documentSchema.parse(body)
    
    // Create document
    const document = await db.document.create({
      data: validatedData,
      include: {
        property: {
          select: { id: true, address: true, city: true }
        },
        uploader: {
          select: { id: true, name: true, email: true }
        }
      }
    })

    return NextResponse.json(document, { status: 201 })
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Validation failed', details: error.issues },
        { status: 400 }
      )
    }
    
    console.error('Error creating document:', error)
    return NextResponse.json(
      { error: 'Failed to create document' },
      { status: 500 }
    )
  }
}