'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from 'next/link'
import { Building2, DollarSign, TrendingUp, BarChart3, Home, AlertTriangle } from "lucide-react"

// Simple test dashboard that bypasses API calls
export default function TestDashboard() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading...</p>
        </div>
      </div>
    )
  }

  // Mock data that doesn't require API calls
  const stats = {
    properties: { total: 3, occupied: 2, vacant: 1, occupancyRate: 66.7 },
    finances: { totalMonthlyRent: 3600, totalIncome: 2280, averageRent: 1200 },
    maintenance: { open: 1, inProgress: 1, completed: 1, total: 3 },
    compliance: { compliant: 2, pending: 1, overdue: 0, total: 3 }
  }

  const formatCurrency = (amount: number) => `£${amount.toLocaleString()}`

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-50">
      {/* Header */}
      <header className="border-b bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 text-white shadow-lg">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center">
                <Building2 className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white">Property Manager Pro</h1>
                <p className="text-sm text-white/80">Test Dashboard</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link href="/">
                <Button variant="outline" size="sm" className="bg-white/10 text-white border-white/30 hover:bg-white/20 backdrop-blur-sm">
                  <Home className="h-4 w-4 mr-2" />
                  Home
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button variant="outline" size="sm" className="bg-white/10 text-white border-white/30 hover:bg-white/20 backdrop-blur-sm">
                  Main Dashboard
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-6 py-8">
        {/* Success Message */}
        <div className="mb-8">
          <Card className="border-green-200 bg-green-50">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                  <AlertTriangle className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-green-800">Test Dashboard Working!</h3>
                  <p className="text-green-700">This dashboard loads without API calls and should work in preview environments.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-blue-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-blue-700">Total Properties</CardTitle>
              <Building2 className="h-4 w-4 text-blue-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">{stats.properties.total}</div>
              <p className="text-xs text-blue-600">
                {stats.properties.occupied} occupied, {stats.properties.vacant} vacant
              </p>
            </CardContent>
          </Card>

          <Card className="border-green-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-green-700">Monthly Rent</CardTitle>
              <DollarSign className="h-4 w-4 text-green-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">{formatCurrency(stats.finances.totalMonthlyRent)}</div>
              <p className="text-xs text-green-600">
                Avg: {formatCurrency(stats.finances.averageRent)}
              </p>
            </CardContent>
          </Card>

          <Card className="border-purple-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-700">Occupancy Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-purple-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">{stats.properties.occupancyRate.toFixed(1)}%</div>
              <p className="text-xs text-purple-600">
                Occupancy rate
              </p>
            </CardContent>
          </Card>

          <Card className="border-orange-200">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-orange-700">Total Income</CardTitle>
              <BarChart3 className="h-4 w-4 text-orange-600" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">{formatCurrency(stats.finances.totalIncome)}</div>
              <p className="text-xs text-orange-600">
                Net income collected
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Instructions */}
        <Card>
          <CardHeader>
            <CardTitle>Preview Environment Issues</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">If you're seeing redirect errors:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li>Clear your browser cache (Ctrl+Shift+R)</li>
                <li>Try incognito/private mode</li>
                <li>The main dashboard may have caching issues in preview environments</li>
                <li>This test dashboard bypasses those issues</li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-semibold mb-2">Local vs Preview Environment:</h4>
              <ul className="list-disc list-inside space-y-1 text-sm text-muted-foreground">
                <li><strong>Local (localhost:3000)</strong>: Works perfectly with all features</li>
                <li><strong>Preview (space.z.ai)</strong>: May have caching/network restrictions</li>
                <li><strong>This test dashboard</strong>: Should work in both environments</li>
              </ul>
            </div>

            <div className="flex gap-2 pt-4">
              <Link href="/dashboard">
                <Button>Try Main Dashboard</Button>
              </Link>
              <Link href="/">
                <Button variant="outline">Return to Home</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}